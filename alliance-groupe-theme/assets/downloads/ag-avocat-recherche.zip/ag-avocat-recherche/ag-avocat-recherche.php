<?php
/**
 * Plugin Name:       AG Recherche Juridique (Avocat)
 * Plugin URI:        https://alliancegroupe-inc.com
 * Description:       Cabinet de recherche juridique pour l'avocat : méta-moteur vers toutes les sources officielles (Légifrance, Cour de cassation/Judilibre, Conseil d'État, Conseil constitutionnel, CEDH, CJUE, EUR-Lex, doctrine, fiscal…), recherche LIVE de jurisprudence via l'API Judilibre (open data, gratuite), salle d'analyse de dossiers (faits / problème de droit / textes / jurisprudence / arguments adverses / parade / stratégie), banque d'arguments réutilisables et assistant IA optionnel. Outil privé (réservé au cabinet, dans le tableau de bord WordPress).
 * Version:           1.6.4
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Alliance Groupe
 * License:           GPL-2.0-or-later
 * Text Domain:       ag-avocat-recherche
 *
 * Plugin AUTONOME et SÉPARÉ des plugins avocat verrouillés (Free / Premium /
 * Business). Aucune dépendance : il fonctionne dès qu'il est activé. Toutes les
 * classes/options sont préfixées `ag_jr_` / `ag-jr-` pour éviter toute collision.
 *
 * Déontologie : outil d'aide à la recherche et à l'analyse pour le
 * professionnel du droit. Il ne donne pas de consultation et n'engage pas la
 * responsabilité du cabinet : l'avocat vérifie toujours les sources primaires.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


// Durcissement securite (xmlrpc, enumeration auteur/REST, en-tetes, versions) — livre avec le plugin
$ag_hard = plugin_dir_path( __FILE__ ) . 'inc/ag-hardening.php';
if ( file_exists( $ag_hard ) ) { require_once $ag_hard; }
define( 'AG_JR_VERSION', '1.6.4' );
define( 'AG_JR_DIR', plugin_dir_path( __FILE__ ) );
define( 'AG_JR_URL', plugin_dir_url( __FILE__ ) );

// Relais Judilibre mutualisé (clé PISTE hébergée par Alliance Groupe) : utilisé
// AUTOMATIQUEMENT quand le cabinet n'a pas saisi sa propre clé → recherche
// jurisprudence incluse, sans aucune configuration côté client.
if ( ! defined( 'AG_JR_PROXY_BASE' ) ) {
	define( 'AG_JR_PROXY_BASE', 'https://alliancegroupe-inc.com/wp-json/ag/v1' );
}

require_once AG_JR_DIR . 'inc/class-ag-recherche-juridique.php';
require_once AG_JR_DIR . 'inc/class-ag-jr-client.php';
require_once AG_JR_DIR . 'inc/class-ag-jr-updater.php';

add_action( 'plugins_loaded', array( 'AG_Recherche_Juridique', 'instance' ) );
add_action( 'plugins_loaded', array( 'AG_JR_Client', 'instance' ) );

// Création des pages / rôles à l'activation (rien de destructif).
register_activation_hook( __FILE__, array( 'AG_Recherche_Juridique', 'on_activate' ) );
register_activation_hook( __FILE__, array( 'AG_JR_Client', 'on_activate' ) );
