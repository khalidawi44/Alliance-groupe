=== AG Starter Restaurant ===

Contributors: adminag
Tags: one-column, custom-menu, featured-images, translation-ready, theme-options, custom-colors, custom-logo, threaded-comments, right-sidebar, block-styles, wide-blocks
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Theme WordPress gratuit 100% francais pour restaurants, plombiers, electriciens, menuisiers, BTP. Design sombre et chaleureux bronze et noir, responsive et rapide. Contenu pre-redige en francais natif : hero, prestations, zones d'intervention, devis, contact. Concu pour que vous n'ayez quasiment rien a changer (95% pret a l'emploi). 

== Description ==

AG Starter Restaurant est un theme WordPress pense pour les restaurants francophones (plombiers, electriciens, menuisiers, macons, chauffagistes, BTP) qui veulent une vitrine en ligne immediatement exploitable, sans perdre des heures a traduire un theme anglais ou a tout reecrire.

Caracteristiques principales :

* 100% francais natif : tous les textes, sections, exemples et horaires sont deja en francais.
* Design sombre chaleureux : palette bronze et noir qui inspire serieux et savoir-faire.
* Pret a l'emploi : remplacez simplement le nom, l'adresse, les horaires et les photos. Le reste est deja en place.
* Responsive : adapte mobile, tablette et desktop — vos clients pourront vous contacter depuis leur smartphone.
* Leger et rapide : aucune dependance JavaScript, chargement instantane.
* Compatible editeur de blocs (Gutenberg), support des alignements large et full width.
* Prepare pour la traduction (translation-ready) avec text-domain dedie.
* Support custom logo, custom background, menu principal, widgets et commentaires threades.
* Aucun plugin requis.

Contenu pre-rempli inclus :

* Hero de bienvenue avec sous-titre et bouton "Demander un devis".
* Trois cartes : Nos prestations, Zones d'intervention, Nos realisations.
* Section "Qui sommes-nous".
* Footer avec adresse, horaires (incluant urgences) et contact.

Vous n'avez qu'a ouvrir les fichiers du theme (ou utiliser l'editeur de site) et remplacer les textes entre crochets par vos informations reelles.

== Installation ==

1. Dans WordPress, allez dans Apparence > Themes > Ajouter.
2. Cliquez sur "Televerser un theme" et choisissez le fichier ag-starter-restaurant.zip.
3. Cliquez sur "Installer maintenant" puis "Activer".
4. Creez une page vide, puis allez dans Reglages > Lecture et choisissez cette page comme "Page d'accueil".
5. Personnalisez le contenu : remplacez les elements entre crochets par vos informations, ajoutez vos photos et c'est pret.
6. (Optionnel) Allez dans Apparence > Menus pour creer un menu principal.
7. (Optionnel) Allez dans Apparence > Widgets pour remplir la barre laterale.

== Frequently Asked Questions ==

= Le theme est-il vraiment gratuit ? =

Oui, 100% gratuit, sous licence GPL v2 ou ulterieure.

= Le theme est-il adapte a plombiers, electriciens, menuisiers, restaurants du batiment ? =

Oui, il a ete pense specifiquement pour ce public, avec des textes et sections adaptes.

= Puis-je personnaliser les couleurs ? =

Oui, les couleurs principales peuvent etre modifiees directement dans style.css.

= Ai-je besoin d'un plugin de page builder ? =

Non. Le theme est entierement fonctionnel sans Elementor, Divi ou autre.

= Qui a cree ce theme ? =

Alliance Group, une agence web et IA. Plus d'infos sur https://alliancegroupe-inc.com

== Changelog ==

= 1.23.6 =
* Systeme de contraste UNIFIE sur tous les modules (carte/menu, commande/livraison, fidelite, recettes) : plus aucun bouton/onglet illisible (fini le rouge-sur-rouge). Onglets de la carte, boutons de deblocage, WhatsApp, cartes de choix : tous lisibles et coherents avec la palette du preset.

= 1.23.5 =
* Menu lisible (couleurs du template) sur toutes les pages internes : fini le survol/onglet blanc invisible sur la Carte, Reservation, etc.
* Tiroir panier decale sous la barre d'admin WordPress (l'en-tete 'Votre commande' n'est plus cache quand on est connecte admin).

= 1.23.4 =
* FIX cartes de choix du hero : texte toujours blanc (une regle globale les rendait rouges) et lisible au survol (plus de texte invisible rouge-sur-rouge).

= 1.23.3 =
* FIX menu sur les articles : le texte du menu prend les couleurs du template (lisible), fini le menu "casse" (texte blanc invisible) au survol/onglet actif.
* Articles recette = de VRAIS articles complets : intro, bandeau (temps/portions/difficulte), ingredients avec quantites, preparation numerotee detaillee, astuces du chef, puis le bloc secret. Les demos sont rafraichies.

= 1.23.2 =
* Articles recette : grande PHOTO en haut + ETAPES claires (Ingredients en liste, Preparation numerotee), cadre lisible. Les 3 recettes de demo sont rafraichies automatiquement.
* FIX affichage : le header transparent de l'accueil debordait sur les articles/archives/recherche/404 -> il est desormais plein et le contenu est decale dessous.

= 1.23.1 =
* Le hero affiche directement les CARTES DE CHOIX sous le titre (Reserver / Se faire livrer / A emporter / Voir la carte) au lieu d'un bouton.
* Reinitialiser : nouveau bouton NETTOYAGE EXHAUSTIF qui supprime aussi tous les articles (hors categorie Recettes) et toutes les pages non-restaurant laisses par d'autres templates.

= 1.23.0 =
* Le bouton "Commander / Reserver" du hero ouvre un POP-UP DE CHOIX directement sur l'accueil (Reserver une table / Se faire livrer / A emporter / Voir la carte).
* Nouveau : RECETTES (aimant a clients) — la grille "Nos specialites" peut etre remplacee par des cartes IMAGE menant a des articles/tutos recettes.
* Ingredients SECRETS caches via [secret]...[/secret] : se debloquent en PAYANT (lien configurable) OU en RESERVANT / SE FAISANT LIVRER (debloque toutes les recettes, offert).
* Reglages dans Personnaliser > Recettes (prix, lien de paiement, code, intro). 3 recettes de demo creees automatiquement.

= 1.22.4 =
* FIX Réinitialiser : le reset (hérité du template artisan) reconstruisait un menu générique (Prestations/Zones/Réalisations/Devis) et supprimait même les pages Carte et Réservation. Il recrée maintenant les bonnes pages restaurant (Notre carte, Réservation, Fidélité, Qui sommes-nous, Contact) et le bon menu, sans toucher aux réglages de fidélité.

= 1.22.3 =
* Menu (header) transparent au-dessus du hero sur l'accueil (texte blanc lisible) ; il devient plein aux couleurs du theme au scroll et sur les pages internes.

= 1.22.2 =
* VRAI correctif palette : le skin "premium-mode" forcait les couleurs Versailles (or & noir) en !important sur toutes les pages, ecrasant le preset. Il suit maintenant la palette active -> Pizzeria devient bien rouge/vert/blanc, Burger rouge/jaune, etc.

= 1.22.1 =
* Correctif palette : apres mise a jour, la palette du preset actif se ré-applique automatiquement (plus besoin de ré-appliquer le preset a la main).
* Le bouton du hero ouvre desormais la carte avec le pop-up de choix (Reserver / Livraison / A emporter / Consulter) au lieu de mener a /reservation/.

= 1.22.0 =
* Themes par type de restaurant POUSSES A FOND : la carte, la commande et la fidelite suivent desormais la palette du preset (plus de doré figé).
* Pizzeria 100% Italie (rouge + vert + blanc), Burger style fast-food (rouge + jaune facon McDo), Bistrot (bois/bordeaux), Gastronomique (noir + champagne), Creperie (bleu Bretagne + caramel), Traditionnel (Versailles or & noir).
* Nouvelle 2e couleur de marque (accent secondaire) + couleur de texte auto-lisible sur les boutons (noir/blanc selon la teinte).
* Grille des specialites de l'accueil alignee sur la palette.

= 1.21.1 =
* Preset Pizzeria/Italien : couleurs de l'Italie (tricolore) — fond creme clair, titres verts, accent rouge, ambiance trattoria.

= 1.21.0 =
* Nouveau : CARTE DE FIDELITE sur la page /fidelite/ (creee automatiquement).
* Le client regle tout (Personnaliser > Carte de fidelite) : tampons ou points, objectif, recompense, bonus de bienvenue, texte.
* Visiteur : inscription en 30s, carte digitale a tampons, retrouve sa carte par email/telephone.
* Restaurant : menu admin "Fidelite" pour ajouter un tampon/des points et valider une recompense ; recherche par nom/email/tel/carte.
* Credit automatique a chaque commande en ligne ; email + notification push quand une recompense est debloquee.

= 1.20.0 =
* Spécialités de l'accueil ENTIÈREMENT éditables par le client : Personnaliser > « Spécialités (accueil) » — 1 ligne par carte « emoji | Titre | lien ».
* Le lien de chaque carte est libre (https://… ou interne /carte/) ; laissé vide, il mène automatiquement à la bonne page.
* Pré-remplissage automatique du champ avec les spécialités du preset (le client part d'une base et modifie).

= 1.19.3 =
* Les cartes "Nos spécialités" de l'accueil mènent enfin quelque part : Réservation/Privatisation/Terrasse -> page Réservation ; À emporter -> carte en mode commande ; Menu/Vins/Desserts/Produits -> la carte.
* La page carte applique directement le choix via ?go=... (plus de pop-up redondant quand on vient d'une spécialité).

= 1.19.2 =
* Correctif : l'écran d'accueil se ferme bien après le choix (bug d'affichage [hidden]).
* Le choix du client (Livraison / À emporter / Consulter) s'affiche dans une barre en haut de la carte, avec un bouton « Changer ».

= 1.19.1 =
* Écran d'accueil à l'arrivée sur la carte : Réserver une table / Livraison / À emporter / Voir la carte (+ horaires).
* Mode "Voir la carte" : consultation simple (boutons Ajouter masqués) ; barre "Changer" pour passer en commande à tout moment.
* Panier réduit (tiroir plus étroit) et ne s'ouvre plus tout seul à chaque ajout (le panier flottant clignote, on l'ouvre quand on veut).
* Nouveau réglage : Horaires d'ouverture (Personnaliser > Commande en ligne).

= 1.19.0 =
* Carte (Notre carte) : fond sombre Versailles -> titres, noms de plats et prix enfin parfaitement lisibles.
* Nouveau : COMMANDE EN LIGNE type Uber Eats sur la page Notre carte (bouton "+ Ajouter", panier flottant, tiroir, validation).
* Modes Livraison (frais + minimum) ou A emporter ; navigation par categories ; option "Commander sur WhatsApp".
* Reception des commandes : email au restaurant + notification push (ag_push) + numero de commande, reglages dans Personnaliser > Commande en ligne.

= 1.0.0 =
* Version initiale.
* Page d'accueil statique avec hero, cartes et section "a propos".
* Templates : index.php, front-page.php, header.php, footer.php, sidebar.php, page.php, single.php, search.php, 404.php, comments.php.
* Prepare pour la traduction.
* Compatible WordPress 6.0+.

== Credits ==

Theme cree par Alliance Group (https://alliancegroupe-inc.com).
Polices systeme uniquement (pas de dependance Google Fonts).
Licence : GPL v2 ou ulterieure.
