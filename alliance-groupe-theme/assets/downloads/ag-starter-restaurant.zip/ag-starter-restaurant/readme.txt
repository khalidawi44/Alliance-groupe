=== AG Starter Restaurant ===

Contributors: adminag
Tags: one-column, custom-menu, featured-images, translation-ready, theme-options, custom-colors, custom-logo, threaded-comments, right-sidebar, block-styles, wide-blocks
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Theme WordPress gratuit 100% francais pour restaurants, plombiers, electriciens, menuisiers, BTP. Design sombre et chaleureux bronze et noir, responsive et rapide. Contenu pre-redige en francais natif : hero, prestations, zones d'intervention, devis, contact. Concu pour que vous n'ayez quasiment rien a changer (95% pret a l'emploi). 

== Description ==

AG Starter Restaurant est un theme WordPress pense pour les restaurants francophones (plombiers, electriciens, menuisiers, macons, chauffagistes, BTP) qui veulent une vitrine en ligne immediatement exploitable, sans perdre des heures a traduire un theme anglais ou a tout reecrire.

Caracteristiques principales :

* 100% francais natif : tous les textes, sections, exemples et horaires sont deja en francais.
* Design sombre chaleureux : palette bronze et noir qui inspire serieux et savoir-faire.
* Pret a l'emploi : remplacez simplement le nom, l'adresse, les horaires et les photos. Le reste est deja en place.
* Responsive : adapte mobile, tablette et desktop — vos clients pourront vous contacter depuis leur smartphone.
* Leger et rapide : aucune dependance JavaScript, chargement instantane.
* Compatible editeur de blocs (Gutenberg), support des alignements large et full width.
* Prepare pour la traduction (translation-ready) avec text-domain dedie.
* Support custom logo, custom background, menu principal, widgets et commentaires threades.
* Aucun plugin requis.

Contenu pre-rempli inclus :

* Hero de bienvenue avec sous-titre et bouton "Demander un devis".
* Trois cartes : Nos prestations, Zones d'intervention, Nos realisations.
* Section "Qui sommes-nous".
* Footer avec adresse, horaires (incluant urgences) et contact.

Vous n'avez qu'a ouvrir les fichiers du theme (ou utiliser l'editeur de site) et remplacer les textes entre crochets par vos informations reelles.

== Installation ==

1. Dans WordPress, allez dans Apparence > Themes > Ajouter.
2. Cliquez sur "Televerser un theme" et choisissez le fichier ag-starter-restaurant.zip.
3. Cliquez sur "Installer maintenant" puis "Activer".
4. Creez une page vide, puis allez dans Reglages > Lecture et choisissez cette page comme "Page d'accueil".
5. Personnalisez le contenu : remplacez les elements entre crochets par vos informations, ajoutez vos photos et c'est pret.
6. (Optionnel) Allez dans Apparence > Menus pour creer un menu principal.
7. (Optionnel) Allez dans Apparence > Widgets pour remplir la barre laterale.

== Frequently Asked Questions ==

= Le theme est-il vraiment gratuit ? =

Oui, 100% gratuit, sous licence GPL v2 ou ulterieure.

= Le theme est-il adapte a plombiers, electriciens, menuisiers, restaurants du batiment ? =

Oui, il a ete pense specifiquement pour ce public, avec des textes et sections adaptes.

= Puis-je personnaliser les couleurs ? =

Oui, les couleurs principales peuvent etre modifiees directement dans style.css.

= Ai-je besoin d'un plugin de page builder ? =

Non. Le theme est entierement fonctionnel sans Elementor, Divi ou autre.

= Qui a cree ce theme ? =

Alliance Group, une agence web et IA. Plus d'infos sur https://alliancegroupe-inc.com

== Changelog ==

= 1.21.0 =
* Nouveau : CARTE DE FIDELITE sur la page /fidelite/ (creee automatiquement).
* Le client regle tout (Personnaliser > Carte de fidelite) : tampons ou points, objectif, recompense, bonus de bienvenue, texte.
* Visiteur : inscription en 30s, carte digitale a tampons, retrouve sa carte par email/telephone.
* Restaurant : menu admin "Fidelite" pour ajouter un tampon/des points et valider une recompense ; recherche par nom/email/tel/carte.
* Credit automatique a chaque commande en ligne ; email + notification push quand une recompense est debloquee.

= 1.20.0 =
* Spécialités de l'accueil ENTIÈREMENT éditables par le client : Personnaliser > « Spécialités (accueil) » — 1 ligne par carte « emoji | Titre | lien ».
* Le lien de chaque carte est libre (https://… ou interne /carte/) ; laissé vide, il mène automatiquement à la bonne page.
* Pré-remplissage automatique du champ avec les spécialités du preset (le client part d'une base et modifie).

= 1.19.3 =
* Les cartes "Nos spécialités" de l'accueil mènent enfin quelque part : Réservation/Privatisation/Terrasse -> page Réservation ; À emporter -> carte en mode commande ; Menu/Vins/Desserts/Produits -> la carte.
* La page carte applique directement le choix via ?go=... (plus de pop-up redondant quand on vient d'une spécialité).

= 1.19.2 =
* Correctif : l'écran d'accueil se ferme bien après le choix (bug d'affichage [hidden]).
* Le choix du client (Livraison / À emporter / Consulter) s'affiche dans une barre en haut de la carte, avec un bouton « Changer ».

= 1.19.1 =
* Écran d'accueil à l'arrivée sur la carte : Réserver une table / Livraison / À emporter / Voir la carte (+ horaires).
* Mode "Voir la carte" : consultation simple (boutons Ajouter masqués) ; barre "Changer" pour passer en commande à tout moment.
* Panier réduit (tiroir plus étroit) et ne s'ouvre plus tout seul à chaque ajout (le panier flottant clignote, on l'ouvre quand on veut).
* Nouveau réglage : Horaires d'ouverture (Personnaliser > Commande en ligne).

= 1.19.0 =
* Carte (Notre carte) : fond sombre Versailles -> titres, noms de plats et prix enfin parfaitement lisibles.
* Nouveau : COMMANDE EN LIGNE type Uber Eats sur la page Notre carte (bouton "+ Ajouter", panier flottant, tiroir, validation).
* Modes Livraison (frais + minimum) ou A emporter ; navigation par categories ; option "Commander sur WhatsApp".
* Reception des commandes : email au restaurant + notification push (ag_push) + numero de commande, reglages dans Personnaliser > Commande en ligne.

= 1.0.0 =
* Version initiale.
* Page d'accueil statique avec hero, cartes et section "a propos".
* Templates : index.php, front-page.php, header.php, footer.php, sidebar.php, page.php, single.php, search.php, 404.php, comments.php.
* Prepare pour la traduction.
* Compatible WordPress 6.0+.

== Credits ==

Theme cree par Alliance Group (https://alliancegroupe-inc.com).
Polices systeme uniquement (pas de dependance Google Fonts).
Licence : GPL v2 ou ulterieure.
