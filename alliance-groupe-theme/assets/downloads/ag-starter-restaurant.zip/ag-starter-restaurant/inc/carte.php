<?php
/**
 * Notre carte (menu du restaurant) — affichage elegant + editable.
 *
 * - Shortcode [ag_restaurant_carte]
 * - Remplace le contenu de la page de slug "carte" par la vraie carte.
 * - Editable dans Apparence > Personnaliser > « Notre carte (menu) » :
 *   format texte simple ("## Section" + "Nom | Description | Prix").
 *
 * @package AG_Starter_Restaurant
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class AG_Restaurant_Carte {

	const OPT = 'ag_restaurant_carte_menu';

	public static function init() {
		add_shortcode( 'ag_restaurant_carte', array( __CLASS__, 'render' ) );
		add_filter( 'the_content', array( __CLASS__, 'maybe_replace' ) );
		add_action( 'customize_register', array( __CLASS__, 'customize' ) );
	}

	public static function default_menu() {
		return "## Entrées\n"
			. "Soupe à l'oignon gratinée | Comté affiné, croûtons maison | 8\n"
			. "Œuf parfait | Crème de champignons, lard fumé | 11\n"
			. "Foie gras maison | Chutney de figues, pain brioché | 16\n\n"
			. "## Plats\n"
			. "Filet de bœuf, sauce au poivre | Gratin dauphinois, légumes du marché | 24\n"
			. "Suprême de volaille fermière | Risotto crémeux au parmesan | 19\n"
			. "Pavé de cabillaud | Beurre blanc, écrasé de pommes de terre | 21\n"
			. "Risotto aux cèpes (végétarien) | Parmesan, huile de truffe | 17\n\n"
			. "## Desserts\n"
			. "Fondant au chocolat | Cœur coulant, glace vanille | 9\n"
			. "Tarte fine aux pommes | Caramel beurre salé | 8\n"
			. "Crème brûlée à la vanille | | 7\n\n"
			. "## Formules\n"
			. "Menu du midi | Entrée + plat ou plat + dessert, en semaine | 18\n"
			. "Menu complet | Entrée + plat + dessert | 29";
	}

	public static function customize( $wp ) {
		$wp->add_section( 'ag_restaurant_carte', array(
			'title'       => '🍽️ ' . __( 'Notre carte (menu)', 'ag-starter-restaurant' ),
			'priority'    => 27,
			'description' => __( 'Une ligne « ## Titre » par section. Un plat par ligne : Nom | Description | Prix (prix vide = aucun prix).', 'ag-starter-restaurant' ),
		) );
		$wp->add_setting( self::OPT, array(
			'default'           => self::default_menu(),
			'sanitize_callback' => array( __CLASS__, 'sanitize' ),
		) );
		$wp->add_control( self::OPT, array(
			'label'       => __( 'Votre carte', 'ag-starter-restaurant' ),
			'section'     => 'ag_restaurant_carte',
			'type'        => 'textarea',
			'input_attrs' => array( 'rows' => 16 ),
		) );
	}

	public static function sanitize( $v ) {
		return wp_kses_post( $v );
	}

	public static function maybe_replace( $content ) {
		if ( is_admin() || ! is_page() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		$post = get_post();
		if ( ! $post || 'carte' !== $post->post_name ) {
			return $content;
		}
		// La carte EST le contenu : on remplace le texte placeholder.
		return self::render();
	}

	/** Carte parsée (sections + items) — réutilisée par la commande en ligne. */
	public static function get_sections() {
		return self::parse( get_theme_mod( self::OPT, self::default_menu() ) );
	}

	private static function parse( $raw ) {
		$sections = array();
		$idx = -1;
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) continue;
			if ( '##' === substr( $line, 0, 2 ) ) {
				$sections[] = array( 'title' => trim( substr( $line, 2 ) ), 'items' => array() );
				$idx = count( $sections ) - 1;
			} elseif ( $idx >= 0 ) {
				$parts = array_map( 'trim', explode( '|', $line ) );
				$sections[ $idx ]['items'][] = array(
					'name'  => isset( $parts[0] ) ? $parts[0] : '',
					'desc'  => isset( $parts[1] ) ? $parts[1] : '',
					'price' => isset( $parts[2] ) ? $parts[2] : '',
				);
			}
		}
		return $sections;
	}

	private static function fmt_price( $p ) {
		$p = trim( $p );
		if ( '' === $p ) return '';
		if ( preg_match( '/^\d+([.,]\d+)?$/', $p ) ) {
			return $p . ' €';
		}
		return $p;
	}

	public static function render() {
		$sections = self::parse( get_theme_mod( self::OPT, self::default_menu() ) );
		if ( empty( $sections ) ) return '';

		ob_start();
		?>
		<section class="ag-carte-menu" style="max-width:780px;margin:30px auto 60px;padding:0 20px;">
			<style>
			/* Anti-fondu AGRESSIF : titres (h1/h2) et noms etaient attenues par
			   une animation/opacite d'apparition. On force TOUT en pleine
			   opacite, sans animation/transform/filtre, avec forte specificite. */
			html body.ag-premium-mode .ag-plain-page,
			html body.ag-premium-mode .ag-plain-page *,
			html body.ag-premium-mode .ag-plain-page h1,
			html body.ag-premium-mode .ag-plain-page h2,
			html body.ag-premium-mode .ag-plain-page h3,
			html body .ag-carte-menu, html body .ag-carte-menu *{
				opacity:1 !important;animation:none !important;transform:none !important;filter:none !important;
				-webkit-text-fill-color:currentColor !important;
			}
			.ag-carte-card{background:linear-gradient(180deg,var(--ag-color-panel),var(--ag-color-panel));border:1px solid color-mix(in srgb, var(--ag-color-accent) 32%, transparent);border-radius:16px;padding:44px 48px;box-shadow:0 20px 60px rgba(0,0,0,.5);}
			@media(max-width:560px){.ag-carte-card{padding:32px 22px;}}
			/* Titre de la page (Notre carte) bien visible aussi */
			html body.ag-premium-mode .ag-plain-page .ag-entry-title{color:var(--ag-color-accent) !important;-webkit-text-fill-color:var(--ag-color-accent) !important;opacity:1 !important;}
			.ag-carte-top{text-align:center;margin-bottom:40px;}
			.ag-carte-card .ag-carte-top__sub{color:var(--ag-color-accent) !important;-webkit-text-fill-color:var(--ag-color-accent) !important;letter-spacing:5px;text-transform:uppercase;font-size:.86rem;font-weight:700;margin:0;}
			.ag-carte-top__rule{width:90px;height:2px;background:var(--ag-color-accent2);margin:14px auto 0;}
			.ag-carte-section{margin-bottom:46px;}
			.ag-carte-section:last-child{margin-bottom:0;}
			.ag-carte-card .ag-carte-section__title{font-family:'Playfair Display',Georgia,serif;color:var(--ag-color-accent) !important;-webkit-text-fill-color:var(--ag-color-accent) !important;font-size:2.1rem;text-align:center;margin:0 0 8px;letter-spacing:.4px;text-shadow:0 1px 3px rgba(0,0,0,.4);}
			.ag-carte-section__rule{width:70px;height:2px;background:var(--ag-color-accent2);margin:0 auto 28px;}
			.ag-carte-item{margin-bottom:22px;}
			.ag-carte-line{display:flex;align-items:baseline;gap:10px;}
			.ag-carte-card .ag-carte-name{color:var(--ag-color-text) !important;-webkit-text-fill-color:var(--ag-color-text) !important;font-weight:700;font-size:1.15rem;text-shadow:0 1px 2px rgba(0,0,0,.45);}
			.ag-carte-dots{flex:1 1 auto;border-bottom:1px dotted color-mix(in srgb, var(--ag-color-accent) 70%, transparent);transform:none;align-self:center;min-width:18px;}
			.ag-carte-card .ag-carte-price{color:var(--ag-color-accent) !important;-webkit-text-fill-color:var(--ag-color-accent) !important;font-weight:800;white-space:nowrap;font-size:1.12rem;}
			.ag-carte-card .ag-carte-desc{color:var(--ag-color-muted) !important;-webkit-text-fill-color:var(--ag-color-muted) !important;font-style:italic;font-size:.96rem;margin-top:4px;line-height:1.5;}
			/* Nav catégories (type Uber Eats) */
			.ag-carte-nav{position:sticky;top:0;z-index:50;display:flex;gap:8px;overflow-x:auto;padding:12px 4px;margin:0 0 26px;background:linear-gradient(180deg,var(--ag-color-panel),color-mix(in srgb, var(--ag-color-panel) 95%, transparent));border-bottom:1px solid color-mix(in srgb, var(--ag-color-accent) 22%, transparent);-webkit-overflow-scrolling:touch;}
			.ag-carte-nav::-webkit-scrollbar{display:none}
			.ag-carte-nav a{flex:0 0 auto;color:var(--ag-color-muted);text-decoration:none;font-weight:600;font-size:.9rem;padding:7px 16px;border:1px solid color-mix(in srgb, var(--ag-color-accent) 40%, transparent);border-radius:999px;white-space:nowrap;transition:.15s;}
			.ag-carte-nav a:hover{background:var(--ag-color-accent);color:var(--ag-color-on-accent)}
			</style>
			<div class="ag-carte-card">
			<div class="ag-carte-top">
				<p class="ag-carte-top__sub">La Carte</p>
				<div class="ag-carte-top__rule"></div>
			</div>
			<?php if ( count( $sections ) > 1 ) : ?>
				<nav class="ag-carte-nav" aria-label="Sections de la carte">
					<?php foreach ( $sections as $sec ) : ?>
						<a href="#<?php echo esc_attr( 'sec-' . sanitize_title( $sec['title'] ) ); ?>"><?php echo esc_html( $sec['title'] ); ?></a>
					<?php endforeach; ?>
				</nav>
			<?php endif; ?>
			<?php foreach ( $sections as $sec ) : ?>
				<div class="ag-carte-section" id="<?php echo esc_attr( 'sec-' . sanitize_title( $sec['title'] ) ); ?>">
					<h2 class="ag-carte-section__title"><?php echo esc_html( $sec['title'] ); ?></h2>
					<div class="ag-carte-section__rule"></div>
					<?php
					$order_on = class_exists( 'AG_Restaurant_Commande' ) && AG_Restaurant_Commande::is_on();
					foreach ( $sec['items'] as $it ) : if ( '' === $it['name'] ) continue;
						$num = $order_on ? AG_Restaurant_Commande::num_price( $it['price'] ) : null;
					?>
						<div class="ag-carte-item">
							<div class="ag-carte-line">
								<span class="ag-carte-name"><?php echo esc_html( $it['name'] ); ?></span>
								<span class="ag-carte-dots"></span>
								<?php $price = self::fmt_price( $it['price'] ); if ( '' !== $price ) : ?>
									<span class="ag-carte-price"><?php echo esc_html( $price ); ?></span>
								<?php endif; ?>
							</div>
							<?php if ( '' !== $it['desc'] ) : ?>
								<div class="ag-carte-desc"><?php echo esc_html( $it['desc'] ); ?></div>
							<?php endif; ?>
							<?php if ( null !== $num ) {
								echo AG_Restaurant_Commande::add_button( AG_Restaurant_Commande::item_id( $sec['title'], $it['name'] ), $it['name'], $num );
							} ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endforeach; ?>
			</div>
		<?php if ( class_exists( 'AG_Restaurant_Commande' ) ) echo AG_Restaurant_Commande::cart_ui(); ?>
		</section>
		<?php
		return ob_get_clean();
	}
}
AG_Restaurant_Carte::init();
