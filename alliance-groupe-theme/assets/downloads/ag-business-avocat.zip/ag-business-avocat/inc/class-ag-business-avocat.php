<?php
/**
 * Main Business class. Singleton.
 *
 * @package AG_Business_Avocat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AG_Business_Avocat {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Hooks always registered; tier check lazy inside each callback.
		add_filter( 'body_class', array( $this, 'add_body_class' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ), 30 );
		add_action( 'wp_head', array( $this, 'output_domaine_bg_overrides' ), 99 );
		add_action( 'init', array( $this, 'reorder_sections' ), 99 );
		add_action( 'admin_init', array( $this, 'ensure_boutique_page' ) );
		add_action( 'admin_init', array( $this, 'ensure_boutique_in_menu' ) );
		add_action( 'admin_init', array( $this, 'ensure_default_domaines' ) );
		add_action( 'admin_init', array( $this, 'ensure_domaines_submenu' ) );
		add_action( 'admin_init', array( $this, 'ensure_legal_pages' ) );
		add_action( 'admin_init', array( $this, 'ensure_boutique_offers' ) );
		add_action( 'admin_init', array( $this, 'ensure_account_pages' ) );
		add_shortcode( 'ag_business_account', array( $this, 'render_account_shortcode' ) );
		add_shortcode( 'ag_business_boutique_grid', array( $this, 'render_boutique_grid_shortcode' ) );
		add_action( 'admin_notices', array( $this, 'woocommerce_admin_notice' ) );
		add_action( 'admin_notices', array( $this, 'stripe_admin_notice' ) );
		// Note : pas de filter the_content pour la team Cabinet — le
		// template page-cabinet.php du theme n'appelle pas the_content.
		// L'injection se fait cote JS via cabinetTeamHtml localise.
		add_filter( 'wp_nav_menu_args', array( $this, 'allow_submenu_depth' ) );
		add_action( 'customize_register', array( $this, 'register_customizer' ), 30 );
	}

	/**
	 * Le theme Free demande wp_nav_menu(depth=1) qui n'affiche que les
	 * items top-level. En Business on autorise les sous-menus.
	 */
	public function allow_submenu_depth( $args ) {
		if ( ! $this->is_active() ) {
			return $args;
		}
		if ( isset( $args['theme_location'] ) && 'primary' === $args['theme_location'] ) {
			$args['depth'] = 0;
		}
		return $args;
	}

	/**
	 * Lazy tier check. Active uniquement si tier === business.
	 */
	private function is_active() {
		if ( ! class_exists( 'AG_Licence_Client' ) ) {
			return false;
		}
		return 'business' === AG_Licence_Client::get_tier();
	}

	public function add_body_class( $classes ) {
		if ( ! $this->is_active() ) {
			return $classes;
		}
		$classes[] = 'ag-business-active';
		return $classes;
	}

	public function enqueue_assets() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( file_exists( AG_BUSINESS_AVOCAT_DIR . 'assets/business.css' ) ) {
			wp_enqueue_style(
				'ag-business-avocat-style',
				AG_BUSINESS_AVOCAT_URL . 'assets/business.css',
				array(),
				AG_BUSINESS_AVOCAT_VERSION
			);
		}
		if ( file_exists( AG_BUSINESS_AVOCAT_DIR . 'assets/business.js' ) ) {
			wp_enqueue_script(
				'ag-business-avocat-script',
				AG_BUSINESS_AVOCAT_URL . 'assets/business.js',
				array(),
				AG_BUSINESS_AVOCAT_VERSION,
				true
			);
			wp_localize_script( 'ag-business-avocat-script', 'agBusinessData', array(
				'honorairesUrl'   => function_exists( 'ag_page_url' ) ? ag_page_url( 'honoraires' ) : home_url( '/honoraires/' ),
				'boutiqueUrl'     => function_exists( 'ag_page_url' ) ? ag_page_url( 'boutique' ) : home_url( '/boutique/' ),
				'domaineUrls'     => $this->get_domaine_urls(),
				'boutiqueSymbol'  => (string) get_theme_mod( 'ag_business_boutique_symbol', 'stars' ),
				'stripeUrls'      => array(
					(string) get_theme_mod( 'ag_business_honoraires_first_stripe', '' ),
					(string) get_theme_mod( 'ag_business_honoraires_pack_stripe', '' ),
					(string) get_theme_mod( 'ag_business_honoraires_hour_stripe', '' ),
				),
				// HTML de l'equipe injecte uniquement sur la page Cabinet
				// (le template Free n'appelle pas the_content donc on
				// passe par JS). Split en 2 groupes pour permettre
				// d'inserer des citations entre.
				'cabinetAssociatesHtml'    => is_page( 'cabinet' ) ? $this->render_team_group_html( 'associates', __( 'Avocats associés', 'ag-business-avocat' ) ) : '',
				'cabinetCollaboratorsHtml' => is_page( 'cabinet' ) ? $this->render_team_group_html( 'collaborators', __( 'Collaborateurs', 'ag-business-avocat' ) ) : '',
				// Citations parallax injectees entre les sections des
				// pages internes (cabinet, honoraires, expertise).
				// JAMAIS apres le titre haut de page (.ag-page-hero).
				'pageCitations'            => $this->get_page_citations_data(),
				// URLs d'images pour les 3 offres Boutique sur la home —
				// JS les injecte dans les cards si pas deja presentes.
				'boutiqueOfferImages'      => $this->get_boutique_offer_images(),
			) );
		}
	}

	/**
	 * Liste les permaliens des 12 premiers domaines, dans l'ordre meme
	 * que ce que rend le template Free, pour que :nth-child et l'index
	 * JS pointent vers la bonne URL.
	 */
	private function get_domaine_urls() {
		if ( ! function_exists( 'ag_starter_avocat_get_domaines' ) ) {
			return array();
		}
		$domaines = ag_starter_avocat_get_domaines( 12 );
		$urls     = array();
		foreach ( (array) $domaines as $d ) {
			$urls[] = get_permalink( $d->ID );
		}
		return $urls;
	}

	/**
	 * Print inline CSS that overrides the background image of each
	 * "Domaines d'expertise" card on the front page in Business tier.
	 *
	 * Self-contained : marche meme si le plugin Premium n'est pas
	 * active. Lit les images Customizer Premium si presentes (compat),
	 * sinon utilise une slug-map et un pool curatee identique a Premium.
	 */
	public function output_domaine_bg_overrides() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( ! function_exists( 'ag_starter_avocat_get_domaines' ) ) {
			return;
		}
		$domaines = ag_starter_avocat_get_domaines( 12 );
		if ( ! $domaines ) {
			return;
		}
		$slug_map = array(
			'droit-des-affaires'           => 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1600&q=85',
			'droit-du-travail'             => 'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=1600&q=85',
			'droit-de-la-famille'          => 'https://images.unsplash.com/photo-1609220136736-443140cffec6?w=1600&q=85',
			'droit-immobilier'             => 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=1600&q=85',
			'droit-penal'                  => 'https://images.unsplash.com/photo-1589994965851-a8f479c573a9?w=1600&q=85',
			'droit-fiscal'                 => 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=1600&q=85',
			'droit-international'          => 'https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?w=1600&q=85',
			'droit-de-la-securite-sociale' => 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=1600&q=85',
			'droit-des-successions'        => 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=1600&q=85',
			'droit-du-numerique'           => 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=1600&q=85',
			'droit-bancaire'               => 'https://images.unsplash.com/photo-1601597111158-2fceff292cdc?w=1600&q=85',
			'droit-de-la-consommation'     => 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=1600&q=85',
		);
		$pool = array(
			'https://images.unsplash.com/photo-1505664194779-8beaceb93744?w=1600&q=85',
			'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1600&q=85',
			'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=1600&q=85',
			'https://images.unsplash.com/photo-1609220136736-443140cffec6?w=1600&q=85',
			'https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=1600&q=85',
			'https://images.unsplash.com/photo-1589994965851-a8f479c573a9?w=1600&q=85',
			'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=1600&q=85',
			'https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?w=1600&q=85',
			'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=1600&q=85',
			'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=1600&q=85',
			'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=1600&q=85',
			'https://images.unsplash.com/photo-1601597111158-2fceff292cdc?w=1600&q=85',
		);

		$css = '';
		$idx = 0;
		foreach ( $domaines as $d ) {
			$idx++;
			if ( has_post_thumbnail( $d->ID ) ) {
				continue;
			}
			$slug = $d->post_name;
			// 1) override Customizer Premium (compat), 2) slug map, 3) pool
			$customizer_key = 'ag_premium_img_' . str_replace( '-', '_', $slug );
			$customizer_url = (string) get_theme_mod( $customizer_key, '' );
			if ( $customizer_url ) {
				$url = $customizer_url;
			} elseif ( isset( $slug_map[ $slug ] ) ) {
				$url = $slug_map[ $slug ];
			} else {
				$url = $pool[ ( $idx - 1 ) % count( $pool ) ];
			}
			$css .= sprintf(
				"body.ag-business-active .ag-domaines__grid > .ag-domaine-card:nth-child(%d) .ag-domaine-card__bg{background-image:url('%s')!important;}\n",
				$idx,
				esc_url_raw( $url )
			);
			// Belt-and-suspenders : si .ag-domaine-card__bg n'est pas rendu
			// (cas Free fallback ou structure modifiee), on pose l'image
			// directement sur la card parente.
			$css .= sprintf(
				"body.ag-business-active .ag-domaines__grid > .ag-domaine-card:nth-child(%d){background-image:url('%s')!important;background-size:cover!important;background-position:center!important;}\n",
				$idx,
				esc_url_raw( $url )
			);
		}
		if ( $css ) {
			echo "<style id=\"ag-business-domaine-bg\">\n" . $css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Sur la home, ordre demande par l'utilisateur :
	 *   Maitre -> 2 associes -> Notre equipe (collaborateurs)
	 *
	 * On laisse render_team_section a sa position par defaut
	 * (ag_after_maitre @ 10) et on ajoute la section associes en
	 * priorite 5 pour qu'elle apparaisse AVANT.
	 */
	public function reorder_sections() {
		if ( ! $this->is_active() ) {
			return;
		}
		// render_team_section reste a sa position par defaut
		// (ag_after_maitre priorite 10 — registree par pro-features.php).
		// On ajoute juste les 2 associes AVANT (priorite 5).
		add_action( 'ag_after_maitre', array( $this, 'render_home_associates' ), 5 );
	}

	/**
	 * Rend les 2 avocats associes sous le Maitre sur la home.
	 * Le team_section qui suit (priorite 10) affiche les collaborateurs.
	 */
	public function render_home_associates() {
		if ( ! $this->is_active() ) {
			return;
		}
		echo $this->render_team_group_html( 'associates', __( 'Avocats associés', 'ag-business-avocat' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Cree la page "Boutique" en Business si elle n'existe pas. Le contenu
	 * pose un shortcode WooCommerce — fallback texte si WC absent.
	 */
	public function ensure_boutique_page() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$desired_content = class_exists( 'WooCommerce' )
			? '[ag_business_boutique_grid]'
			: '<!-- WooCommerce non installe — la boutique apparaitra ici une fois le plugin active. -->';

		// Si une page existe deja (boutique/shop/magasin), on met a jour
		// son contenu si c'etait notre placeholder ou l'ancien shortcode.
		$existing = get_page_by_path( 'boutique' );
		if ( ! $existing ) {
			// Cherche shop/magasin si existes (eg WC l'a cree)
			foreach ( array( 'shop', 'magasin' ) as $alt ) {
				$found = get_posts( array(
					'name'           => $alt,
					'post_type'      => 'page',
					'post_status'    => array( 'publish', 'draft' ),
					'posts_per_page' => 1,
				) );
				if ( ! empty( $found ) ) {
					$existing = $found[0];
					break;
				}
			}
		}

		if ( $existing ) {
			// Update si contenu = ancien default ou ancien shortcode WC
			$current  = trim( (string) $existing->post_content );
			$old_defs = array(
				'[products limit="12" columns="3"]',
				'[products]',
				'<!-- WooCommerce non installe — la boutique apparaitra ici une fois le plugin active. -->',
				'',
			);
			if ( in_array( $current, $old_defs, true ) && $current !== trim( $desired_content ) ) {
				wp_update_post( array(
					'ID'           => $existing->ID,
					'post_content' => $desired_content,
				) );
			}
			return;
		}

		// Pas de page existante, on cree
		wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => __( 'Boutique', 'ag-business-avocat' ),
			'post_name'    => 'boutique',
			'post_content' => $desired_content,
		) );
	}

	/**
	 * Shortcode [ag_business_boutique_grid] : rend les produits WC
	 * avec le meme style .ag-boutique-card que la section Boutique
	 * de la home. Pas de WC -> message d'attente.
	 */
	public function render_boutique_grid_shortcode() {
		if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_products' ) ) {
			return '<p style="text-align:center;padding:40px;">' . esc_html__( 'WooCommerce n\'est pas activé. La boutique sera disponible dès l\'activation du plugin.', 'ag-business-avocat' ) . '</p>';
		}

		$products = wc_get_products( array(
			'limit'   => 12,
			'status'  => 'publish',
			'orderby' => 'date',
			'order'   => 'DESC',
		) );

		if ( empty( $products ) ) {
			return '<p style="text-align:center;padding:40px;">' . esc_html__( 'Aucun produit dans la boutique pour le moment.', 'ag-business-avocat' ) . '</p>';
		}

		ob_start();
		?>
		<div class="ag-section ag-boutique ag-business-boutique-page" id="ag-boutique">
			<div class="ag-container">
				<div class="ag-boutique__grid">
					<?php foreach ( $products as $product ) :
						if ( ! is_object( $product ) ) continue;
						$img_id  = $product->get_image_id();
						$img_url = $img_id ? wp_get_attachment_image_url( $img_id, 'large' ) : '';
						$price   = wp_strip_all_tags( $product->get_price_html() );
						$excerpt = $product->get_short_description();
						if ( '' === $excerpt ) {
							$excerpt = wp_trim_words( wp_strip_all_tags( $product->get_description() ), 24 );
						}
						$has_image = ! empty( $img_url );
						?>
						<article class="ag-boutique-card<?php echo $has_image ? ' ag-boutique-card--with-image' : ''; ?>">
							<?php if ( $has_image ) : ?>
								<div class="ag-boutique-card__image">
									<img src="<?php echo esc_url( $img_url ); ?>" alt="<?php echo esc_attr( $product->get_name() ); ?>" loading="lazy">
								</div>
							<?php endif; ?>
							<h3 class="ag-boutique-card__title"><?php echo esc_html( $product->get_name() ); ?></h3>
							<div class="ag-boutique-card__price"><?php echo esc_html( $price ); ?></div>
							<p class="ag-boutique-card__desc"><?php echo esc_html( $excerpt ); ?></p>
							<a href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>" class="ag-btn ag-boutique-card__btn"><?php esc_html_e( 'Voir la fiche →', 'ag-business-avocat' ); ?></a>
						</article>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Ajoute la page Boutique au menu primaire en Business si elle n'y
	 * est pas deja. Idempotent : ne re-ajoute pas un item qui existe.
	 */
	public function ensure_boutique_in_menu() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$page = get_page_by_path( 'boutique' );
		if ( ! $page ) {
			return;
		}
		$locations = (array) get_theme_mod( 'nav_menu_locations' );
		$menu_id   = isset( $locations['primary'] ) ? (int) $locations['primary'] : 0;
		if ( ! $menu_id ) {
			return;
		}
		$items = wp_get_nav_menu_items( $menu_id );
		if ( $items ) {
			foreach ( $items as $item ) {
				if ( 'post_type' === $item->type && (int) $item->object_id === (int) $page->ID ) {
					return; // deja present
				}
			}
		}
		wp_update_nav_menu_item( $menu_id, 0, array(
			'menu-item-title'     => __( 'Boutique', 'ag-business-avocat' ),
			'menu-item-object'    => 'page',
			'menu-item-object-id' => $page->ID,
			'menu-item-type'      => 'post_type',
			'menu-item-status'    => 'publish',
		) );
	}

	/**
	 * Affiche un admin notice qui propose d'installer WooCommerce quand
	 * Business est actif mais que WooCommerce ne l'est pas. Lien direct
	 * vers l'installation 1-clic via update.php.
	 */
	public function woocommerce_admin_notice() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( ! current_user_can( 'install_plugins' ) ) {
			return;
		}
		if ( class_exists( 'WooCommerce' ) ) {
			return;
		}
		$install_url = wp_nonce_url(
			self_admin_url( 'update.php?action=install-plugin&plugin=woocommerce' ),
			'install-plugin_woocommerce'
		);
		$browse_url = self_admin_url( 'plugin-install.php?s=woocommerce&tab=search&type=term' );
		?>
		<div class="notice notice-info" style="border-left-color:#D4B45C;">
			<p style="font-size:14px;">
				<strong><?php esc_html_e( 'AG Business :', 'ag-business-avocat' ); ?></strong>
				<?php esc_html_e( 'pour activer la page Boutique, installez WooCommerce.', 'ag-business-avocat' ); ?>
				&nbsp;
				<a href="<?php echo esc_url( $install_url ); ?>" class="button button-primary"><?php esc_html_e( 'Installer WooCommerce', 'ag-business-avocat' ); ?></a>
				<a href="<?php echo esc_url( $browse_url ); ?>" class="button"><?php esc_html_e( 'Voir dans la liste', 'ag-business-avocat' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Cree les 12 domaines de droit FR par defaut (CPT ag_domaine) si ils
	 * n'existent pas. Skip ceux deja crees par l'utilisateur (par slug).
	 */
	public function ensure_default_domaines() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! post_type_exists( 'ag_domaine' ) ) {
			return;
		}
		foreach ( $this->get_default_domaines_data() as $slug => $data ) {
			$existing = get_page_by_path( $slug, OBJECT, 'ag_domaine' );
			if ( $existing ) {
				continue;
			}
			$id = wp_insert_post( array(
				'post_type'    => 'ag_domaine',
				'post_status'  => 'publish',
				'post_title'   => $data['title'],
				'post_name'    => $slug,
				'post_content' => $data['content'],
				'post_excerpt' => $data['excerpt'],
			) );
			if ( ! is_wp_error( $id ) && $id ) {
				update_post_meta( $id, '_ag_domaine_icon', $data['icon'] );
				update_post_meta( $id, '_ag_domaine_examples', $data['examples'] );
			}
		}
	}

	/**
	 * Ajoute un sous-menu sous l'item "Domaines d'expertise" du menu
	 * primaire avec un item par domaine + un lien final
	 * "Tous les domaines →".
	 */
	public function ensure_domaines_submenu() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$expertise_page = get_page_by_path( 'expertise' );
		if ( ! $expertise_page ) {
			return;
		}
		$locations = (array) get_theme_mod( 'nav_menu_locations' );
		$menu_id   = isset( $locations['primary'] ) ? (int) $locations['primary'] : 0;
		if ( ! $menu_id ) {
			return;
		}
		$items = wp_get_nav_menu_items( $menu_id );
		if ( empty( $items ) ) {
			return;
		}

		// Trouve l'item parent (le lien vers la page Expertise)
		$parent_item = null;
		foreach ( $items as $item ) {
			if ( 'post_type' === $item->type && 'page' === $item->object && (int) $item->object_id === (int) $expertise_page->ID ) {
				$parent_item = $item;
				break;
			}
		}
		if ( ! $parent_item ) {
			return;
		}
		$parent_id = (int) $parent_item->ID;

		// Liste les enfants existants pour idempotence
		$existing_child_object_ids = array();
		$has_tous                  = false;
		foreach ( $items as $item ) {
			if ( (int) $item->menu_item_parent !== $parent_id ) {
				continue;
			}
			if ( 'post_type' === $item->type && 'ag_domaine' === $item->object ) {
				$existing_child_object_ids[] = (int) $item->object_id;
			}
			if ( 'custom' === $item->type && false !== strpos( $item->title, 'Tous les domaines' ) ) {
				$has_tous = true;
			}
		}

		// Ajoute un item enfant par domaine CPT publie
		$domaines = function_exists( 'ag_starter_avocat_get_domaines' ) ? ag_starter_avocat_get_domaines( 20 ) : array();
		$position = 1;
		foreach ( $domaines as $d ) {
			if ( in_array( (int) $d->ID, $existing_child_object_ids, true ) ) {
				$position++;
				continue;
			}
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'     => get_the_title( $d ),
				'menu-item-object'    => 'ag_domaine',
				'menu-item-object-id' => (int) $d->ID,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
				'menu-item-parent-id' => $parent_id,
				'menu-item-position'  => $position++,
			) );
		}

		// Ajoute le lien final "Tous les domaines →" en bas du sous-menu
		if ( ! $has_tous ) {
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'     => __( 'Tous les domaines', 'ag-business-avocat' ),
				'menu-item-url'       => get_permalink( $expertise_page ),
				'menu-item-type'      => 'custom',
				'menu-item-status'    => 'publish',
				'menu-item-parent-id' => $parent_id,
				'menu-item-position'  => 999,
				'menu-item-classes'   => 'ag-business-submenu-tous',
			) );
		}
	}

	/**
	 * Donnees par defaut pour les 12 domaines de droit FR les plus
	 * courants. Chaque entree contient titre, icone, excerpt, contenu,
	 * et 3 exemples de cas.
	 */
	private function get_default_domaines_data() {
		return array(
			'droit-des-affaires' => array(
				'title'    => 'Droit des affaires',
				'icon'     => 'briefcase',
				'excerpt'  => "Conseil et representation des entreprises : creation, contrats commerciaux, contentieux, restructuration.",
				'content'  => "<p>Le droit des affaires regroupe l'ensemble des regles juridiques applicables a la vie des entreprises. Notre cabinet accompagne PME, ETI et grands groupes a chaque etape de leur developpement.</p>",
				'examples' => "Creation et statuts de societes\nNegociation de baux commerciaux\nLitiges entre associes",
			),
			'droit-du-travail' => array(
				'title'    => 'Droit du travail',
				'icon'     => 'shield',
				'excerpt'  => "Defense des salaries et des employeurs : licenciements, contrats, harcelement, ruptures conventionnelles.",
				'content'  => "<p>Notre cabinet conseille et represente salaries et employeurs dans toutes les problematiques liees a la relation de travail.</p>",
				'examples' => "Contestation de licenciement\nRupture conventionnelle\nHarcelement moral / sexuel",
			),
			'droit-de-la-famille' => array(
				'title'    => 'Droit de la famille',
				'icon'     => 'family',
				'excerpt'  => "Divorce, garde d'enfants, succession, adoption, regimes matrimoniaux. Discretion et empathie garanties.",
				'content'  => "<p>Le droit de la famille touche aux moments les plus intimes de la vie. Notre approche : ecoute, transparence, accompagnement personnalise.</p>",
				'examples' => "Divorce par consentement mutuel\nDivorce contentieux\nGarde d'enfants et droit de visite",
			),
			'droit-immobilier' => array(
				'title'    => 'Droit immobilier',
				'icon'     => 'house',
				'excerpt'  => "Acquisition, vente, copropriete, baux, troubles de voisinage, constructions et permis de construire.",
				'content'  => "<p>Conseil et contentieux pour proprietaires, locataires, syndics et professionnels de l'immobilier.</p>",
				'examples' => "Vices caches a l'achat\nLitige de copropriete\nExpulsion de locataire",
			),
			'droit-penal' => array(
				'title'    => 'Droit penal',
				'icon'     => 'gavel',
				'excerpt'  => "Defense penale tous degres de juridiction : garde a vue, comparution immediate, instruction, assises.",
				'content'  => "<p>Defense des justiciables a tous les stades de la procedure penale, en France comme a l'etranger.</p>",
				'examples' => "Garde a vue 24/24\nDefense d'assises\nViolences conjugales",
			),
			'droit-fiscal' => array(
				'title'    => 'Droit fiscal',
				'icon'     => 'document',
				'excerpt'  => "Optimisation, controle fiscal, contentieux, ISF, transmission de patrimoine, fiscalite internationale.",
				'content'  => "<p>Strategie fiscale pour particuliers et entreprises, defense en cas de redressement.</p>",
				'examples' => "Controle fiscal personnel\nContentieux URSSAF\nMontage de holding patrimoniale",
			),
			'droit-international' => array(
				'title'    => 'Droit international',
				'icon'     => 'scales',
				'excerpt'  => "Contrats internationaux, arbitrage, expatriation, fusions transfrontalieres, droit europeen.",
				'content'  => "<p>Accompagnement des entreprises et particuliers dans leurs operations transfrontalieres.</p>",
				'examples' => "Contrat de distribution international\nArbitrage CCI\nDetachement et expatriation",
			),
			'droit-de-la-securite-sociale' => array(
				'title'    => 'Droit de la securite sociale',
				'icon'     => 'heart',
				'excerpt'  => "Accident du travail, maladie professionnelle, invalidite, pensions, contentieux URSSAF.",
				'content'  => "<p>Defense des assures sociaux face aux organismes : CPAM, URSSAF, MSA, RSI.</p>",
				'examples' => "Reconnaissance d'accident du travail\nFaute inexcusable de l'employeur\nLitige sur taux d'invalidite",
			),
			'droit-des-successions' => array(
				'title'    => 'Droit des successions',
				'icon'     => 'document',
				'excerpt'  => "Succession, donation, testament, liquidation, partage, fiscalite successorale, indivision.",
				'content'  => "<p>Anticiper la transmission du patrimoine ou regler une succession contestee dans le respect des heritiers.</p>",
				'examples' => "Liquidation de succession\nContestation de testament\nDonation-partage",
			),
			'droit-du-numerique' => array(
				'title'    => 'Droit du numerique',
				'icon'     => 'lock',
				'excerpt'  => "RGPD, propriete intellectuelle, e-commerce, cybersecurite, contrats SaaS, donnees personnelles.",
				'content'  => "<p>Conformite et contentieux pour les acteurs de l'economie digitale.</p>",
				'examples' => "Mise en conformite RGPD\nContrat SaaS B2B\nViolation de donnees",
			),
			'droit-bancaire' => array(
				'title'    => 'Droit bancaire',
				'icon'     => 'bank',
				'excerpt'  => "Credit immobilier, taux d'usure, cautionnement, contentieux bancaire, surendettement, fraudes.",
				'content'  => "<p>Defense des particuliers et professionnels face aux etablissements bancaires.</p>",
				'examples' => "Pret immobilier sureleve\nFraude bancaire en ligne\nMise en jeu de caution",
			),
			'droit-de-la-consommation' => array(
				'title'    => 'Droit de la consommation',
				'icon'     => 'shield',
				'excerpt'  => "Garanties, vices caches, demarchage, credit conso, clauses abusives, action de groupe.",
				'content'  => "<p>Defense des droits des consommateurs face aux professionnels.</p>",
				'examples' => "Vice cache automobile\nDemarchage abusif\nClause abusive bancaire",
			),
		);
	}

	/**
	 * Cree les pages legales standards d'un site (mentions legales,
	 * RGPD, cookies, CGV, retour). Skip ce qui existe deja par slug.
	 * Le contenu est un template avec des [BRACKETS] pour le cabinet.
	 */
	public function ensure_legal_pages() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		// Slugs alternatifs auto-crees par WP/WC/themes — si l'un
		// d'eux existe (meme en brouillon), on ne cree pas de doublon.
		$alias_map = array(
			'politique-confidentialite' => array( 'privacy-policy', 'politique-de-confidentialite', 'politique-confidentialite-rgpd' ),
			'politique-retour'          => array( 'refund_returns', 'remboursement-et-retour', 'politique-de-retour', 'politique-de-remboursement', 'politique-de-retour-et-de-remboursement' ),
			'cgv'                       => array( 'terms', 'conditions-generales-de-vente', 'conditions-generales', 'terms-and-conditions' ),
			'mentions-legales'          => array( 'legal-notice', 'mentions-legal' ),
			'politique-cookies'         => array( 'politique-de-cookies', 'cookies-policy', 'cookie-policy' ),
		);
		foreach ( $this->get_legal_pages_data() as $slug => $data ) {
			$check = isset( $alias_map[ $slug ] ) ? array_merge( array( $slug ), $alias_map[ $slug ] ) : array( $slug );
			if ( $this->page_exists_any_status( $check ) ) {
				continue;
			}
			wp_insert_post( array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => $data['title'],
				'post_name'    => $slug,
				'post_content' => $data['content'],
			) );
		}
	}

	/**
	 * Verifie si une page avec l'un des slugs donnes existe dans
	 * n'importe quel statut (publish, draft, pending, private, future).
	 * Plus permissif que get_page_by_path (qui ne voit que publish).
	 *
	 * @param string|array $slugs Un slug ou liste de slugs alternatifs.
	 * @param string       $post_type post_type (default 'page').
	 */
	private function page_exists_any_status( $slugs, $post_type = 'page' ) {
		$slugs = (array) $slugs;
		foreach ( $slugs as $slug ) {
			$found = get_posts( array(
				'name'           => $slug,
				'post_type'      => $post_type,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			) );
			if ( ! empty( $found ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Customizer panel "AG Business — Options" : motif Boutique +
	 * autres futurs reglages Business.
	 */
	public function register_customizer( $wp_customize ) {
		$wp_customize->add_panel( 'ag_business_panel', array(
			'title'    => __( 'AG Business — Options', 'ag-business-avocat' ),
			'priority' => 220,
		) );

		// Section Boutique
		$wp_customize->add_section( 'ag_business_boutique', array(
			'title' => __( 'Boutique — motif anime', 'ag-business-avocat' ),
			'panel' => 'ag_business_panel',
		) );
		$wp_customize->add_setting( 'ag_business_boutique_symbol', array(
			'default'           => 'stars',
			'sanitize_callback' => array( $this, 'sanitize_boutique_symbol' ),
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( 'ag_business_boutique_symbol', array(
			'label'       => __( 'Motif anime de la section Boutique', 'ag-business-avocat' ),
			'description' => __( 'Choisir le symbole qui apparait en warp-speed dans la section Boutique de la home, ou desactiver l\'effet.', 'ag-business-avocat' ),
			'section'     => 'ag_business_boutique',
			'type'        => 'select',
			'choices'     => array(
				'stars'  => __( 'Etoiles (par defaut)', 'ag-business-avocat' ),
				'scales' => __( 'Balance de la justice', 'ag-business-avocat' ),
				'gavel'  => __( 'Marteau de juge', 'ag-business-avocat' ),
				'pillar' => __( 'Colonne classique', 'ag-business-avocat' ),
				'none'   => __( 'Desactiver', 'ag-business-avocat' ),
			),
		) );

		// Section Honoraires — liens Stripe
		$wp_customize->add_section( 'ag_business_stripe', array(
			'title'       => __( 'Honoraires — liens Stripe', 'ag-business-avocat' ),
			'description' => __( "Coller l'URL d'un Stripe Payment Link pour chaque palier. Pour creer un lien : dashboard Stripe > Produits > Ajouter > Creer un lien de paiement. Si le champ est vide, aucun bouton n'apparait sur la card.", 'ag-business-avocat' ),
			'panel'       => 'ag_business_panel',
		) );
		$tiers = array(
			'first' => __( 'URL Stripe — 1ère consultation', 'ag-business-avocat' ),
			'pack'  => __( 'URL Stripe — Forfait', 'ag-business-avocat' ),
			'hour'  => __( 'URL Stripe — Au temps passé', 'ag-business-avocat' ),
		);
		foreach ( $tiers as $key => $label ) {
			$setting_key = "ag_business_honoraires_{$key}_stripe";
			$wp_customize->add_setting( $setting_key, array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'refresh',
			) );
			$wp_customize->add_control( $setting_key, array(
				'label'   => $label,
				'section' => 'ag_business_stripe',
				'type'    => 'url',
			) );
		}
	}

	public function sanitize_boutique_symbol( $value ) {
		$valid = array( 'stars', 'scales', 'gavel', 'pillar', 'none' );
		return in_array( $value, $valid, true ) ? $value : 'stars';
	}

	/**
	 * Affiche un admin notice qui propose d'installer un plugin Stripe
	 * (WP Simple Pay) quand Business est actif et qu'aucun plugin Stripe
	 * n'est detecte. Lien direct vers update.php install.
	 */
	public function stripe_admin_notice() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( ! current_user_can( 'install_plugins' ) ) {
			return;
		}
		// Si un plugin Stripe-like est deja la, on n'affiche rien.
		if ( class_exists( 'SimplePay\\Core\\Plugin' )
			|| class_exists( 'WC_Stripe_Helper' )
			|| function_exists( 'simpay_get_setting' ) ) {
			return;
		}
		// slug WP officiel : "stripe" (WP Simple Pay)
		$install_url = wp_nonce_url(
			self_admin_url( 'update.php?action=install-plugin&plugin=stripe' ),
			'install-plugin_stripe'
		);
		$browse_url = self_admin_url( 'plugin-install.php?s=stripe&tab=search&type=term' );
		?>
		<div class="notice notice-info" style="border-left-color:#635BFF;">
			<p style="font-size:14px;">
				<strong><?php esc_html_e( 'AG Business :', 'ag-business-avocat' ); ?></strong>
				<?php esc_html_e( 'pour accepter les paiements Stripe directement sur le site, installez WP Simple Pay (gratuit).', 'ag-business-avocat' ); ?>
				&nbsp;
				<a href="<?php echo esc_url( $install_url ); ?>" class="button button-primary"><?php esc_html_e( 'Installer WP Simple Pay', 'ag-business-avocat' ); ?></a>
				<a href="<?php echo esc_url( $browse_url ); ?>" class="button"><?php esc_html_e( 'Voir tous les plugins Stripe', 'ag-business-avocat' ); ?></a>
				&nbsp;
				<em style="font-size:.85em;color:#666;"><?php esc_html_e( 'Ou utilisez les Stripe Payment Links sans plugin (URLs paramétrables dans le Customizer).', 'ag-business-avocat' ); ?></em>
			</p>
		</div>
		<?php
	}

	/**
	 * Templates legaux pour un site d'avocat. Marqueurs [crochets] que
	 * le cabinet doit completer apres creation.
	 */
	private function get_legal_pages_data() {
		return array(
			'mentions-legales' => array(
				'title'   => 'Mentions légales',
				'content' => $this->legal_template_mentions(),
			),
			'politique-confidentialite' => array(
				'title'   => 'Politique de confidentialité (RGPD)',
				'content' => $this->legal_template_rgpd(),
			),
			'politique-cookies' => array(
				'title'   => 'Politique de cookies',
				'content' => $this->legal_template_cookies(),
			),
			'cgv' => array(
				'title'   => 'Conditions générales de vente',
				'content' => $this->legal_template_cgv(),
			),
			'politique-retour' => array(
				'title'   => 'Politique de retour',
				'content' => $this->legal_template_retour(),
			),
		);
	}

	private function legal_template_mentions() {
		return '<p><em>Page generee automatiquement par AG Business. Remplacez les [crochets] par vos coordonnees.</em></p>
<h2>Editeur du site</h2>
<p><strong>[Nom du cabinet]</strong><br>
[Adresse complete]<br>
SIRET : [numero SIRET]<br>
Numero TVA intracommunautaire : [FR XX XXX XXX XXX]<br>
Email : [email@cabinet.fr]<br>
Telephone : [01 23 45 67 89]<br>
Inscription au Barreau de [Ville] sous le numero [numero]</p>
<h2>Directeur de la publication</h2>
<p>[Nom et prenom du Maitre], avocat au Barreau de [Ville].</p>
<h2>Hebergement</h2>
<p>[Nom de l\'hebergeur]<br>
[Adresse]<br>
Telephone : [telephone]</p>
<h2>Propriete intellectuelle</h2>
<p>L\'ensemble du contenu (textes, images, logos, structure) du present site est la propriete exclusive de [Nom du cabinet]. Toute reproduction, meme partielle, sans accord ecrit prealable est interdite.</p>
<h2>Credits</h2>
<p>Theme : AG Starter Avocat — <a href="https://alliancegroupe-inc.com" target="_blank" rel="noopener">alliancegroupe-inc.com</a></p>';
	}

	private function legal_template_rgpd() {
		return '<p><em>Page generee automatiquement par AG Business. Adaptez aux specificites de votre cabinet.</em></p>
<p>La presente politique decrit comment [Nom du cabinet] collecte, utilise et protege vos donnees personnelles, conformement au Reglement General sur la Protection des Donnees (RGPD) et a la loi Informatique et Libertes.</p>
<h2>1. Responsable du traitement</h2>
<p><strong>[Nom du cabinet]</strong>, [adresse], represente par Maitre [Nom], avocat au Barreau de [Ville]. Contact : [email].</p>
<h2>2. Donnees collectees</h2>
<ul>
<li>Identite : nom, prenom, civilite, date de naissance</li>
<li>Coordonnees : email, telephone, adresse postale</li>
<li>Donnees professionnelles : profession, employeur, situation</li>
<li>Donnees liees au dossier : faits, pieces communiquees, correspondances</li>
<li>Donnees techniques : adresse IP, logs de connexion, cookies (voir politique cookies)</li>
</ul>
<h2>3. Finalites du traitement</h2>
<ul>
<li>Gestion des dossiers juridiques et representation</li>
<li>Communication avec les clients</li>
<li>Facturation et comptabilite</li>
<li>Respect des obligations professionnelles et reglementaires</li>
<li>Statistiques anonymisees du site (audience)</li>
</ul>
<h2>4. Base legale</h2>
<p>Les donnees sont traitees sur la base de l\'execution d\'un contrat (mandat de l\'avocat), du consentement (formulaire de contact) ou d\'une obligation legale (conservation des dossiers).</p>
<h2>5. Duree de conservation</h2>
<p>Les dossiers sont conserves <strong>5 ans apres la fin de la mission</strong>, conformement aux obligations de l\'article 2.2 du Reglement Interieur National. Les pieces comptables sont conservees 10 ans.</p>
<h2>6. Destinataires des donnees</h2>
<p>Les donnees sont accessibles uniquement aux avocats et collaborateurs du cabinet, soumis au secret professionnel. Aucune donnee n\'est cedee a des tiers a des fins commerciales.</p>
<h2>7. Vos droits</h2>
<p>Vous disposez des droits suivants : acces, rectification, effacement, limitation du traitement, portabilite, opposition. Pour exercer ces droits, contactez-nous a [email]. Vous pouvez egalement saisir la CNIL (<a href="https://www.cnil.fr" target="_blank" rel="noopener">www.cnil.fr</a>).</p>
<h2>8. Securite</h2>
<p>Le cabinet met en oeuvre des mesures techniques et organisationnelles appropriees pour proteger vos donnees contre la perte, l\'acces non autorise, la divulgation et la modification.</p>';
	}

	private function legal_template_cookies() {
		return '<p><em>Page generee automatiquement par AG Business. Adaptez selon les services tiers que vous utilisez.</em></p>
<h2>Qu\'est-ce qu\'un cookie ?</h2>
<p>Un cookie est un petit fichier texte depose sur votre terminal lors de la consultation d\'un site web. Il permet au site de reconnaitre votre navigateur et de memoriser certaines informations vous concernant.</p>
<h2>Cookies utilises sur ce site</h2>
<table>
<thead><tr><th>Cookie</th><th>Finalite</th><th>Duree</th></tr></thead>
<tbody>
<tr><td>wordpress_*</td><td>Authentification administrateur</td><td>Session</td></tr>
<tr><td>wp-settings-*</td><td>Preferences interface admin</td><td>1 an</td></tr>
<tr><td>ag_mode</td><td>Choix du mode jour / nuit</td><td>Persistant (localStorage)</td></tr>
</tbody>
</table>
<h2>Comment refuser ou supprimer les cookies ?</h2>
<p>Vous pouvez configurer votre navigateur pour refuser les cookies ou supprimer ceux deja deposes :</p>
<ul>
<li>Chrome : Reglages → Confidentialite et securite → Cookies</li>
<li>Firefox : Preferences → Vie privee et securite</li>
<li>Safari : Preferences → Confidentialite</li>
<li>Edge : Parametres → Cookies et autorisations</li>
</ul>
<p>Le refus de certains cookies peut alterer le fonctionnement du site.</p>';
	}

	private function legal_template_cgv() {
		return '<p><em>Page generee automatiquement par AG Business. A faire valider par le batonnier de votre Barreau.</em></p>
<h2>Article 1 — Objet</h2>
<p>Les presentes conditions generales regissent les ventes de produits et services proposes par <strong>[Nom du cabinet]</strong> via le site [URL] ou en cabinet.</p>
<h2>Article 2 — Prix</h2>
<p>Les prix sont indiques en euros TTC. La TVA applicable est de 20 % pour les prestations juridiques. Le cabinet se reserve le droit de modifier ses tarifs a tout moment, etant entendu que la prestation sera facturee sur la base du tarif en vigueur a la commande.</p>
<h2>Article 3 — Commande</h2>
<p>Toute commande implique l\'acceptation sans reserve des presentes CGV. La commande est consideree comme ferme et definitive apres reception du paiement.</p>
<h2>Article 4 — Paiement</h2>
<p>Les paiements s\'effectuent par carte bancaire, virement, ou cheque. Pour les prestations juridiques, une convention d\'honoraires ecrite est signee avant toute intervention.</p>
<h2>Article 5 — Livraison / Execution</h2>
<p>Les prestations dematerialisees (consultations en ligne, guides PDF) sont accessibles immediatement apres paiement. Les prestations en cabinet sont planifiees selon les disponibilites convenues.</p>
<h2>Article 6 — Retractation</h2>
<p>Conformement a l\'article L221-18 du Code de la consommation, le client dispose d\'un delai de <strong>14 jours</strong> pour exercer son droit de retractation, sauf pour les prestations entierement executees a sa demande explicite avant la fin de ce delai.</p>
<h2>Article 7 — Responsabilite</h2>
<p>La responsabilite du cabinet ne peut etre engagee qu\'en cas de faute prouvee. Elle est limitee au montant des honoraires effectivement percus.</p>
<h2>Article 8 — Litiges</h2>
<p>Tout litige releve de la competence des tribunaux du ressort de la Cour d\'appel de [Ville]. Le client peut egalement recourir a la mediation de la consommation.</p>';
	}

	private function legal_template_retour() {
		return '<p><em>Page generee automatiquement par AG Business. Concerne uniquement les ventes de produits/services dematerialises.</em></p>
<h2>Droit de retractation</h2>
<p>Conformement aux articles L221-18 et suivants du Code de la consommation, vous disposez de <strong>14 jours calendaires</strong> a compter de la conclusion du contrat pour vous retracter, sans avoir a justifier de motifs ni a payer de penalites.</p>
<h2>Comment exercer le droit de retractation ?</h2>
<p>Pour exercer votre droit, vous devez nous notifier votre decision avant l\'expiration du delai par :</p>
<ul>
<li>Email a : [email@cabinet.fr]</li>
<li>Courrier postal a : [Adresse]</li>
</ul>
<p>Indiquez vos nom, adresse, le numero de la commande et la date.</p>
<h2>Effets de la retractation</h2>
<p>Nous vous remboursons l\'integralite des sommes versees, dans un delai de <strong>14 jours</strong> a compter de la reception de votre demande, par le meme moyen de paiement utilise pour la commande.</p>
<h2>Exceptions</h2>
<p>Le droit de retractation ne peut etre exerce pour :</p>
<ul>
<li>Les prestations entierement executees avant la fin du delai de 14 jours, avec votre accord prealable et explicite</li>
<li>Les contenus numeriques telecharges (guides PDF) une fois l\'acces fourni, avec votre accord</li>
<li>Les services confidentiels de defense penale en cas d\'urgence</li>
</ul>
<h2>Contestation</h2>
<p>En cas de litige, contactez-nous d\'abord pour tenter une resolution amiable. A defaut, vous pouvez saisir le mediateur de la consommation ou le Conseil de l\'Ordre du Barreau de [Ville].</p>';
	}

	/**
	 * Cree les 3 offres affichees dans la section Boutique de la home,
	 * pour qu'elles existent en tant que produits WooCommerce (si actif)
	 * ou pages classiques (fallback). Met a jour les theme_mod URLs
	 * pour que les cards de la home pointent vers les bonnes pages.
	 *
	 * Idempotent : skip si l'offre existe deja (par slug).
	 */
	public function ensure_boutique_offers() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$offers = $this->get_default_offers_data();

		if ( class_exists( 'WC_Product_Simple' ) ) {
			// WooCommerce actif : creer un WC_Product_Simple
			foreach ( $offers as $slug => $data ) {
				if ( get_page_by_path( $slug, OBJECT, 'product' ) ) {
					continue;
				}
				$product = new WC_Product_Simple();
				$product->set_name( $data['title'] );
				$product->set_slug( $slug );
				$product->set_status( 'publish' );
				$product->set_catalog_visibility( 'visible' );
				$product->set_regular_price( (string) $data['price_value'] );
				$product->set_short_description( $data['desc'] );
				$product->set_description( $data['long_desc'] );
				$product->set_virtual( true ); // services dematerialises
				$product->save();
			}
			return;
		}

		// WooCommerce absent : pages classiques + theme_mod URLs
		$shop_keys = array( 'ag_business_shop_1_url', 'ag_business_shop_2_url', 'ag_business_shop_3_url' );
		$i         = 0;
		foreach ( $offers as $slug => $data ) {
			$key = isset( $shop_keys[ $i ] ) ? $shop_keys[ $i ] : null;
			$i++;
			if ( ! $key ) {
				break;
			}
			$page = get_page_by_path( $slug );
			if ( ! $page && ! $this->page_exists_any_status( $slug ) ) {
				$page_id = wp_insert_post( array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => $data['title'],
					'post_name'    => $slug,
					'post_content' => '<p class="ag-offer-price"><strong>' . esc_html( $data['price_value'] ) . ' €</strong></p>' . $data['long_desc'],
				) );
				if ( is_wp_error( $page_id ) ) {
					continue;
				}
				$page = get_post( $page_id );
			}
			if ( ! $page ) {
				continue; // page existe en draft mais pas published — on saute
			}
			$url = get_permalink( $page );
			$current = (string) get_theme_mod( $key, '' );
			if ( '' === $current || '#' === $current ) {
				set_theme_mod( $key, $url );
			}
		}
	}

	/**
	 * Donnees des 3 offres par defaut affichees dans la section Boutique
	 * de la home (alignees avec les defaults de pro-features.php).
	 */
	/**
	 * Liste les URLs d'images des 3 offres dans le meme ordre que
	 * render_boutique() affiche les cards. Permet a JS d'injecter
	 * une .ag-boutique-card__image en fallback Customizer (sans WC)
	 * ou en complement quand le produit WC n'a pas d'image.
	 */
	private function get_boutique_offer_images() {
		$images = array();
		foreach ( $this->get_default_offers_data() as $slug => $data ) {
			$images[] = isset( $data['image'] ) ? $data['image'] : '';
		}
		return $images;
	}

	private function get_default_offers_data() {
		return array(
			'pack-3-consultations-telephoniques' => array(
				'title'       => '3 consultations téléphoniques',
				'desc'        => 'Pack de 3 consultations de 30 min, valables 6 mois. Conseil juridique sur tout domaine.',
				'image'       => 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800&q=85',
				'price_value' => 450,
				'long_desc'   => '<h2>Contenu du pack</h2>
<ul>
<li>3 consultations téléphoniques de 30 minutes chacune</li>
<li>Validité : 6 mois à compter de la commande</li>
<li>Tous domaines de droit couverts</li>
<li>Disponibles du lundi au vendredi 9h-18h</li>
<li>Compte-rendu écrit après chaque consultation (sur demande)</li>
</ul>
<h2>Pour qui ?</h2>
<p>Particuliers et indépendants ayant besoin d\'un avis juridique rapide, sans déplacement au cabinet.</p>
<h2>Comment ça marche</h2>
<ol>
<li>Vous commandez le pack en ligne</li>
<li>Vous recevez un email de confirmation avec le numéro à appeler</li>
<li>Vous prenez rendez-vous au moment qui vous convient</li>
<li>Le Maître vous rappelle à l\'heure convenue</li>
</ol>',
			),
			'guide-juridique-pdf' => array(
				'title'       => 'Guide juridique PDF',
				'desc'        => 'Manuel pratique 80 pages : vos droits face au licenciement, à la séparation, aux litiges courants.',
				'image'       => 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=800&q=85',
				'price_value' => 29,
				'long_desc'   => '<h2>Sommaire du guide</h2>
<ul>
<li>Droit du travail : licenciement, rupture conventionnelle, harcèlement</li>
<li>Droit de la famille : divorce, garde d\'enfants, pension</li>
<li>Droit immobilier : bail, vices cachés, copropriété</li>
<li>Droit de la consommation : démarchage, garanties, litiges</li>
<li>Modèles de courriers types prêts à utiliser</li>
</ul>
<h2>Format</h2>
<p>Document PDF de 80 pages, téléchargeable immédiatement après commande. Imprimable. Mises à jour gratuites pendant 12 mois.</p>',
			),
			'audit-contractuel' => array(
				'title'       => 'Audit contractuel',
				'desc'        => 'Analyse complète d\'un contrat (CDI, bail, partenariat) avec rapport écrit et recommandations.',
				'image'       => 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800&q=85',
				'price_value' => 290,
				'long_desc'   => '<h2>Ce que vous obtenez</h2>
<ul>
<li>Lecture intégrale du contrat (jusqu\'à 30 pages)</li>
<li>Rapport écrit (8-12 pages) avec analyse clause par clause</li>
<li>Identification des points à risque et clauses abusives</li>
<li>Recommandations de modifications</li>
<li>Suggestions de négociation</li>
<li>Délai : 5 jours ouvrés</li>
</ul>
<h2>Types de contrats</h2>
<p>CDI / CDD, contrats de bail (commercial, habitation), contrats commerciaux et de partenariat, contrats de prestations de services, conditions générales, etc.</p>
<h2>Comment commander</h2>
<ol>
<li>Vous commandez l\'audit en ligne</li>
<li>Vous recevez un email avec un lien sécurisé pour téléverser le contrat</li>
<li>Le Maître vous envoie le rapport sous 5 jours ouvrés</li>
<li>Une visioconférence de 30 min est offerte pour clarifier les points</li>
</ol>',
			),
		);
	}

	/**
	 * Construit le HTML d'un groupe d'equipe (associes OU collaborateurs)
	 * en tant que section autonome. Permet a JS d'inserer chaque groupe
	 * a une position differente avec une citation entre.
	 *
	 * @param string $type 'associates' ou 'collaborators'
	 * @param string $title titre H2 du groupe
	 */
	private function render_team_group_html( $type, $title ) {
		$team = $this->get_default_team_data();
		if ( ! isset( $team[ $type ] ) || empty( $team[ $type ] ) ) {
			return '';
		}
		$members = $team[ $type ];
		ob_start();
		?>
		<section class="ag-business-team-full ag-business-team-full--<?php echo esc_attr( $type ); ?>">
			<h2 class="ag-business-team-full__group-title"><?php echo esc_html( $title ); ?></h2>
			<div class="ag-business-team-full__grid ag-business-team-full__grid--<?php echo esc_attr( $type ); ?>">
				<?php foreach ( $members as $m ) {
					echo $this->render_team_card_html( $m ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				} ?>
			</div>
		</section>
		<?php
		return ob_get_clean();
	}

	private function render_team_card_html( $m ) {
		ob_start();
		?>
		<article class="ag-business-team-card">
			<div class="ag-business-team-card__photo" style="background-image:url('<?php echo esc_url( $m['photo'] ); ?>');" aria-hidden="true"></div>
			<div class="ag-business-team-card__body">
				<header class="ag-business-team-card__header">
					<h3 class="ag-business-team-card__name"><?php echo esc_html( $m['name'] ); ?></h3>
					<p class="ag-business-team-card__role"><?php echo esc_html( $m['role'] ); ?></p>
					<p class="ag-business-team-card__barreau"><?php echo esc_html( $m['barreau'] ); ?></p>
				</header>
				<p class="ag-business-team-card__bio"><?php echo esc_html( $m['bio'] ); ?></p>
				<div class="ag-business-team-card__details">
					<div class="ag-business-team-card__block">
						<h4><?php esc_html_e( 'Spécialités', 'ag-business-avocat' ); ?></h4>
						<ul>
							<?php foreach ( $m['specialties'] as $s ) : ?>
								<li><?php echo esc_html( $s ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
					<div class="ag-business-team-card__block">
						<h4><?php esc_html_e( 'Formation', 'ag-business-avocat' ); ?></h4>
						<ul>
							<?php foreach ( $m['education'] as $e ) : ?>
								<li><?php echo esc_html( $e ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
					<div class="ag-business-team-card__block">
						<h4><?php esc_html_e( 'Langues', 'ag-business-avocat' ); ?></h4>
						<p><?php echo esc_html( implode( ', ', $m['languages'] ) ); ?></p>
					</div>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	/**
	 * 5 profils par defaut, separes en 2 groupes :
	 *   - associates : 2 avocats associes (premier conteneur, en avant)
	 *   - collaborators : 3 collaborateurs (deuxieme conteneur)
	 * Photos depuis Unsplash (portraits libres), remplacables.
	 */
	private function get_default_team_data() {
		return array(
			'associates'    => array(
				array(
				'name'        => 'Maître Sophie DUPONT',
				'role'        => 'Avocate associée fondatrice',
				'barreau'     => 'Barreau de Paris — Inscrite depuis 2008',
				'photo'       => 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&q=85',
				'specialties' => array(
					'Droit des affaires',
					'Fusions-acquisitions',
					'Droit des sociétés',
					'Contentieux commercial',
				),
				'education'   => array(
					'Master 2 Droit des affaires — Université Paris II Panthéon-Assas',
					'DJCE (Diplôme de Juriste Conseil d\'Entreprise)',
					'CAPA — École de Formation du Barreau (EFB)',
					'LL.M. en droit international — King\'s College London',
				),
				'languages'   => array( 'Français', 'Anglais', 'Italien' ),
				'bio'         => 'Plus de 15 ans d\'expérience en accompagnement de PME et ETI. Reconnue pour son approche pragmatique et sa capacité à dénouer les contentieux complexes.',
			),
			array(
				'name'        => 'Maître Philippe MARTIN',
				'role'        => 'Avocat associé',
				'barreau'     => 'Barreau de Paris — Inscrit depuis 2012',
				'photo'       => 'https://images.unsplash.com/photo-1556157382-97eda2d62296?w=600&q=85',
				'specialties' => array(
					'Droit pénal',
					'Droit pénal des affaires',
					'Procédure pénale',
					'Garde à vue 24h/24',
				),
				'education'   => array(
					'Master 2 Droit pénal — Université Paris I Panthéon-Sorbonne',
					'CAPA — EFB (Major de promotion)',
					'Stage final auprès du Tribunal Judiciaire de Paris',
				),
				'languages'   => array( 'Français', 'Anglais', 'Espagnol' ),
				'bio'         => 'Ancien collaborateur de cabinets pénalistes parisiens reconnus. Plaidoiries devant toutes les juridictions, de l\'instruction à la cour d\'assises.',
			),
		),
		'collaborators' => array(
			array(
				'name'        => 'Maître Camille LEROUX',
				'role'        => 'Avocate collaboratrice senior',
				'barreau'     => 'Barreau de Paris — Inscrite depuis 2016',
				'photo'       => 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=600&q=85',
				'specialties' => array(
					'Droit du travail',
					'Droit social',
					'Contentieux prud\'homal',
					'Négociation de ruptures conventionnelles',
				),
				'education'   => array(
					'Master 2 Droit social — Université Paris-Nanterre',
					'Diplôme universitaire en Droit de la sécurité sociale',
					'CAPA — EFB',
				),
				'languages'   => array( 'Français', 'Anglais' ),
				'bio'         => 'Spécialiste du droit du travail côté salariés et employeurs. A obtenu plus de 200 décisions favorables devant les Conseils de Prud\'hommes.',
			),
			array(
				'name'        => 'Maître Antoine BERNARD',
				'role'        => 'Avocat collaborateur',
				'barreau'     => 'Barreau de Paris — Inscrit depuis 2020',
				'photo'       => 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=85',
				'specialties' => array(
					'Droit immobilier',
					'Droit de la copropriété',
					'Baux commerciaux et d\'habitation',
					'Vices cachés et constructions',
				),
				'education'   => array(
					'Master 2 Droit immobilier — Université Aix-Marseille',
					'Diplôme universitaire en Construction',
					'CAPA — EFB',
				),
				'languages'   => array( 'Français', 'Anglais' ),
				'bio'         => 'Expertise pointue en contentieux immobilier et copropriété. Conseille promoteurs, syndics et particuliers dans toutes leurs problématiques.',
			),
			array(
				'name'        => 'Maître Léa DUBOIS',
				'role'        => 'Avocate collaboratrice',
				'barreau'     => 'Barreau de Paris — Inscrite depuis 2021',
				'photo'       => 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=600&q=85',
				'specialties' => array(
					'Droit de la famille',
					'Divorce et séparation',
					'Droit des successions',
					'Médiation familiale',
				),
				'education'   => array(
					'Master 2 Droit de la famille — Université Paris II Panthéon-Assas',
					'Diplôme universitaire en Médiation',
					'CAPA — EFB',
				),
				'languages'   => array( 'Français', 'Anglais', 'Allemand' ),
				'bio'         => 'Approche humaine et discrète des dossiers familiaux. Privilégie la médiation et le consentement mutuel quand c\'est possible.',
			),
		),
	);
	}

	/**
	 * Citations juridiques + image de fond a injecter entre les
	 * sections de chaque page interne (cabinet, honoraires, expertise,
	 * rendez-vous). Format : tableau d'objets {quote, author, bg,
	 * insertAfter (selecteur DOM)}. La home a deja ses propres
	 * citations parallax via render_parallax_quote_X de pro-features.
	 */
	private function get_page_citations_data() {
		$citations = array();

		// REGLE : jamais de citation directement apres le titre de page
		// (.ag-page-hero). Les transitions s'inserent uniquement entre
		// des sections de contenu.

		if ( is_page( 'cabinet' ) ) {
			// Cabinet : Cicéron entre associes et collaborateurs,
			//           Pascal entre collaborateurs et "Nous trouver".
			$citations[] = array(
				'quote'       => 'Le silence est une chose admirable, mais qui demande une grande force pour ne pas être faiblesse.',
				'author'      => 'Cicéron',
				'bg'          => 'https://images.unsplash.com/photo-1589216532372-1c2a367900d9?w=1920&q=85',
				'insertAfter' => '.ag-business-team-full--associates',
			);
			$citations[] = array(
				'quote'       => 'La justice sans la force est impuissante ; la force sans la justice est tyrannique.',
				'author'      => 'Blaise Pascal',
				'bg'          => 'https://images.unsplash.com/photo-1505664194779-8beaceb93744?w=1920&q=85',
				'insertAfter' => '.ag-business-team-full--collaborators',
			);
		}

		if ( is_page( 'honoraires' ) ) {
			// Honoraires : citation entre la grille de paliers et la
			// section FAQ (page-article).
			$citations[] = array(
				'quote'       => 'Le contrat est la loi des parties.',
				'author'      => 'Code civil, article 1103',
				'bg'          => 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=1920&q=85',
				'insertAfter' => '.ag-honoraires',
			);
		}

		if ( is_page( 'expertise' ) ) {
			// Expertise : citation apres la grille des domaines.
			$citations[] = array(
				'quote'       => 'Nul n\'est censé ignorer la loi.',
				'author'      => 'Adage du droit français',
				'bg'          => 'https://images.unsplash.com/photo-1589994965851-a8f479c573a9?w=1920&q=85',
				'insertAfter' => '.ag-domaines',
			);
		}

		// Rendez-vous : pas de citation (page courte form-only).

		return $citations;
	}

	/**
	 * Cree les pages compte (Mon compte, Connexion, Inscription) si
	 * elles n'existent pas. Si WooCommerce est actif, on utilise son
	 * shortcode [woocommerce_my_account] qui gere connexion + register
	 * + tableau de bord. Sinon notre shortcode [ag_business_account].
	 *
	 * Active aussi les inscriptions WP (users_can_register) si pas
	 * deja active. Idempotent.
	 */
	public function ensure_account_pages() {
		if ( ! $this->is_active() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Active inscriptions ouvertes si pas deja
		if ( '0' === get_option( 'users_can_register' ) || ! get_option( 'users_can_register' ) ) {
			update_option( 'users_can_register', 1 );
		}

		$wc_active = class_exists( 'WooCommerce' );

		$pages = array(
			'mon-compte' => array(
				'title'   => 'Mon compte',
				'content' => $wc_active
					? '[woocommerce_my_account]'
					: '<p>Bienvenue sur votre espace personnel.</p>[ag_business_account]',
			),
			'connexion'  => array(
				'title'   => 'Connexion',
				'content' => $wc_active
					? '<p>[woocommerce_my_account]</p>'
					: '<p>Identifiez-vous pour accéder à votre espace.</p>[ag_business_account view="login"]',
			),
			'inscription' => array(
				'title'   => 'Inscription',
				'content' => $wc_active
					? '<p>[woocommerce_my_account]</p>'
					: '<p>Créez votre compte pour suivre vos commandes et rendez-vous.</p>[ag_business_account view="register"]',
			),
		);

		// Slugs alternatifs (WC cree my-account, theme parfois variants FR)
		$account_aliases = array(
			'mon-compte'  => array( 'my-account', 'compte' ),
			'connexion'   => array( 'login', 'se-connecter' ),
			'inscription' => array( 'register', 's-inscrire' ),
		);
		foreach ( $pages as $slug => $data ) {
			$check = isset( $account_aliases[ $slug ] ) ? array_merge( array( $slug ), $account_aliases[ $slug ] ) : array( $slug );
			if ( $this->page_exists_any_status( $check ) ) {
				continue;
			}
			wp_insert_post( array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => $data['title'],
				'post_name'    => $slug,
				'post_content' => $data['content'],
			) );
		}

		// Configure les pages WooCommerce si WC est actif et que les
		// pages 'myaccount' / 'shop' n'ont pas ete configurees.
		if ( $wc_active ) {
			$mon_compte = get_page_by_path( 'mon-compte' );
			if ( $mon_compte && ! get_option( 'woocommerce_myaccount_page_id' ) ) {
				update_option( 'woocommerce_myaccount_page_id', $mon_compte->ID );
			}
		}
	}

	/**
	 * Shortcode [ag_business_account] : fallback compte sans WooCommerce.
	 * Vues : 'login' (formulaire connexion), 'register' (inscription),
	 * ou auto (dashboard si connecte, login si non).
	 */
	public function render_account_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'view' => 'auto' ), $atts );
		$view = $atts['view'];

		ob_start();

		if ( is_user_logged_in() && 'login' !== $view && 'register' !== $view ) {
			$user = wp_get_current_user();
			?>
			<div class="ag-business-account ag-business-account--dashboard">
				<h3 class="ag-business-account__greeting">Bonjour <?php echo esc_html( $user->display_name ); ?></h3>
				<p>Connecté en tant que <strong><?php echo esc_html( $user->user_email ); ?></strong></p>
				<ul class="ag-business-account__links">
					<li><a href="<?php echo esc_url( admin_url( 'profile.php' ) ); ?>">Modifier mon profil</a></li>
					<?php if ( current_user_can( 'edit_posts' ) ) : ?>
						<li><a href="<?php echo esc_url( admin_url() ); ?>">Tableau de bord</a></li>
					<?php endif; ?>
					<li><a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>">Se déconnecter</a></li>
				</ul>
			</div>
			<?php
		} elseif ( 'register' === $view ) {
			?>
			<div class="ag-business-account ag-business-account--register">
				<h3>Créer un compte</h3>
				<form method="post" action="<?php echo esc_url( site_url( 'wp-login.php?action=register', 'login_post' ) ); ?>" class="ag-business-account-form">
					<p>
						<label for="user_login">Identifiant</label>
						<input type="text" name="user_login" id="user_login" required autocomplete="username">
					</p>
					<p>
						<label for="user_email">Email</label>
						<input type="email" name="user_email" id="user_email" required autocomplete="email">
					</p>
					<p class="ag-business-account-form__submit">
						<button type="submit" class="ag-btn">S'inscrire</button>
					</p>
					<p class="ag-business-account-form__footnote">
						Déjà un compte ? <a href="<?php echo esc_url( home_url( '/connexion/' ) ); ?>">Se connecter</a>
					</p>
				</form>
			</div>
			<?php
		} else {
			// Login (par defaut)
			?>
			<div class="ag-business-account ag-business-account--login">
				<h3>Se connecter</h3>
				<?php
				wp_login_form( array(
					'redirect'       => home_url( '/mon-compte/' ),
					'label_username' => 'Identifiant ou email',
					'label_password' => 'Mot de passe',
					'label_remember' => 'Se souvenir de moi',
					'label_log_in'   => 'Se connecter',
				) );
				?>
				<p class="ag-business-account-form__footnote">
					Pas encore de compte ? <a href="<?php echo esc_url( home_url( '/inscription/' ) ); ?>">S'inscrire</a>
					&nbsp;·&nbsp;
					<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>">Mot de passe oublié ?</a>
				</p>
			</div>
			<?php
		}

		return ob_get_clean();
	}
}
