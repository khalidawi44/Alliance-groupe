=== AG Starter Avocat ===

Contributors: adminag
Tags: one-column, custom-menu, featured-images, translation-ready, theme-options, custom-colors, custom-logo, threaded-comments, right-sidebar, block-styles, wide-blocks
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.1.18
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Theme gratuit basique 100% francais pour cabinet d'avocats, juriste, notaire, conseil juridique. Structure minimaliste navy et champagne, responsive, sans fioritures. Contenu pre-redige en francais natif, pret a l'emploi.

== Description ==

AG Starter Avocat est un theme pense pour les cabinets d'avocats, juristes, notaires et professions juridiques francophones qui veulent une vitrine en ligne immediatement exploitable, sans perdre des heures a traduire un theme anglais ou a tout reecrire.

Caracteristiques principales :

* 100% francais natif : tous les textes, sections et exemples sont deja en francais.
* Design sombre serieux : palette navy et champagne qui inspire confiance et professionnalisme.
* Pret a l'emploi : remplacez simplement le nom du cabinet, l'adresse, les horaires et les domaines d'expertise. Le reste est deja en place.
* Responsive : adapte mobile, tablette et desktop.
* Leger et rapide : aucune dependance JavaScript, chargement instantane.
* Compatible editeur de blocs (Gutenberg), support des alignements large et full width.
* Prepare pour la traduction (translation-ready) avec text-domain dedie.
* Support custom logo, custom background, menu principal, widgets et commentaires threades.
* Aucun plugin requis.

Contenu pre-rempli inclus :

* Hero d'accueil avec sous-titre et bouton "Prendre rendez-vous".
* Trois cartes : Domaines d'expertise, Honoraires, Prendre rendez-vous.
* Section "Notre cabinet".
* Footer avec cabinet, horaires (visio incluse) et contact.

Vous n'avez qu'a ouvrir le customizer (Apparence > Personnaliser > AG Starter — Personnalisation) et remplacer les textes entre crochets par vos informations reelles.

== Installation ==

1. Dans WordPress, allez dans Apparence > Themes > Ajouter.
2. Cliquez sur "Televerser un theme" et choisissez le fichier ag-starter-avocat.zip.
3. Cliquez sur "Installer maintenant" puis "Activer".
4. Creez une page vide, puis allez dans Reglages > Lecture et choisissez cette page comme "Page d'accueil".
5. Personnalisez le contenu via Apparence > Personnaliser.

== Frequently Asked Questions ==

= Le theme est-il vraiment gratuit ? =

Oui, 100% gratuit, sous licence GPL v2 ou ulterieure.

= Le theme est-il adapte aux cabinets d'avocats ? =

Oui, il a ete pense specifiquement pour les professions juridiques avec des textes et sections adaptes (domaines d'expertise, honoraires, confidentialite, prise de rendez-vous).

= Puis-je personnaliser les couleurs ? =

Oui, directement depuis Apparence > Personnaliser > AG Starter — Personnalisation.

= Ai-je besoin d'un plugin de page builder ? =

Non. Le theme est entierement fonctionnel sans Elementor, Divi ou autre.

= Qui a cree ce theme ? =

Alliance Group, une agence web et IA. Plus d'infos sur https://alliancegroupe-inc.com

== Changelog ==

= 1.1.18 =
* Ecran de bienvenue : ajout d'un lien optionnel vers un guide gratuit (7 pages qui attirent des clients) heberge sur le site de l'auteur. Lien non bloquant, aucune collecte de donnees dans le theme.

= 1.1.13 =
* Creation automatique des 3 pages legales (Mentions legales, Politique de confidentialite RGPD, Cookies) a l'activation, avec contenu pre-redige a completer. Leurs liens apparaissent alors automatiquement dans le bandeau du pied de page.

= 1.1.12 =
* Deontologie-ready : suppression des temoignages clients (interdits par le RIN art. 10 / vade-mecum CNB). La section "Temoignages" du Personnalisateur est remplacee par une note d'explication, sans champ de saisie.
* Nouveau bandeau pied de page : liens Mentions legales / Politique de confidentialite (RGPD) / Cookies (affiches si les pages existent) + rappels secret professionnel, hebergement en Union Europeenne et absence de cookie de tracage.
* Nouvelle section "Deontologie & RGPD" dans le Personnalisateur (notes hebergement et cookies editables ; le barreau d'inscription est repris de la fiche du Maitre).

= 1.0.0 =
* Version initiale.
* Page d'accueil statique avec hero, cartes Domaines/Honoraires/Rendez-vous et section "Notre cabinet".
* Templates : index.php, front-page.php, header.php, footer.php, sidebar.php, page.php, single.php, search.php, 404.php, comments.php.
* Customizer integre (couleurs, typo, hero, footer).
* Banniere "Ameliorer mon theme" dans le customizer avec liens vers les packs Premium/Business.
* Prepare pour la traduction.
* Compatible WordPress 6.0+.

== Copyright ==

AG Starter Avocat WordPress Theme, Copyright 2026 AGthemes.
AG Starter Avocat is distributed under the terms of the GNU GPL v2 or later.

This theme, like WordPress itself, is licensed under the GPL.
Use it to make something cool, have fun, and share what you've learned with others.

License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Resources / Bundled assets ==

* screenshot.png — original work by AGthemes, licensed GPL v2 or later (same as the theme).
* No third-party images are bundled or referenced by the theme.
* Fonts: system fonts only (no Google Fonts dependency).

== Credits ==

Theme created by AGthemes (https://alliancegroupe-inc.com).
