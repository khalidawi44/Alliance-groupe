<?php
/**
 * Plugin Name:       AG Starter Companion
 * Plugin URI:        https://alliancegroupe-inc.com/templates-wordpress
 * Description:       Importer un clic pour les themes AG Starter (Restaurant, Artisan, Coach, Avocat). Cree automatiquement les pages, le menu et les reglages pour un site pret a l'emploi.
 * Version:           1.12.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            AGthèmes
 * Author URI:        https://alliancegroupe-inc.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ag-starter-companion
 * Domain Path:       /languages
 *
 * @package AG_Starter_Companion
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AG_STARTER_COMPANION_VERSION', '1.12.0' );
define( 'AG_STARTER_COMPANION_FILE', __FILE__ );

/**
 * Main plugin class.
 */
class AG_Starter_Companion {

	/**
	 * Constructor : wire WordPress hooks.
	 */
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		add_action( 'admin_menu', array( $this, 'register_admin_page' ) );
		add_action( 'admin_notices', array( $this, 'admin_notice' ) );
		add_action( 'admin_init', array( $this, 'maybe_auto_reimport' ) );
		add_action( 'admin_init', array( $this, 'maybe_fix_theme_menu' ) );

		// CPT « Domaine d'expertise » (Avocat) — fourni par le PLUGIN (conformité
		// WordPress.org : un thème ne doit pas enregistrer de CPT). Gardé par
		// post_type_exists() → pas de double si le thème l'enregistre déjà.
		add_action( 'init', array( $this, 'register_avocat_domaine_cpt' ), 9 );
		add_action( 'add_meta_boxes', array( $this, 'avocat_domaine_metabox' ) );
		add_action( 'save_post_ag_domaine', array( $this, 'avocat_domaine_save_meta' ) );

		// Personnalisation Premium (Alliance) : image de hero modifiable + effets
		// visuels premium, communs a tous les themes AG Starter.

		// Self-updater: check for new versions of this plugin

		// Enable auto-updates by default for this plugin

		// Admin notice when update is available
	}

	/**
	 * Load translations.
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'ag-starter-companion', false, dirname( plugin_basename( AG_STARTER_COMPANION_FILE ) ) . '/languages' );
	}

	/**
	 * CPT « Domaine d'expertise » (Avocat). Enregistré par le plugin pour la
	 * conformité WordPress.org. N'agit que si le thème Avocat est actif et que
	 * le CPT n'est pas déjà enregistré (évite le double avec la version premium).
	 */
	public function register_avocat_domaine_cpt() {
		if ( 'ag-starter-avocat' !== $this->get_active_theme_slug() ) {
			return;
		}
		if ( post_type_exists( 'ag_domaine' ) ) {
			return;
		}
		register_post_type( 'ag_domaine', array(
			'labels' => array(
				'name'          => __( 'Domaines d\'expertise', 'ag-starter-companion' ),
				'singular_name' => __( 'Domaine d\'expertise', 'ag-starter-companion' ),
				'menu_name'     => __( 'Domaines', 'ag-starter-companion' ),
				'add_new_item'  => __( 'Ajouter un domaine', 'ag-starter-companion' ),
				'edit_item'     => __( 'Modifier le domaine', 'ag-starter-companion' ),
				'all_items'     => __( 'Tous les domaines', 'ag-starter-companion' ),
				'not_found'     => __( 'Aucun domaine trouve.', 'ag-starter-companion' ),
			),
			'public'        => true,
			'show_ui'       => true,
			'show_in_menu'  => true,
			'menu_icon'     => 'dashicons-portfolio',
			'menu_position' => 22,
			'rewrite'       => array( 'slug' => 'domaine' ),
			'has_archive'   => true,
			'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'custom-fields' ),
			'show_in_rest'  => true,
		) );
	}

	public function avocat_domaine_metabox() {
		if ( 'ag-starter-avocat' !== $this->get_active_theme_slug() ) {
			return;
		}
		add_meta_box( 'ag_domaine_meta', __( 'Détails du domaine', 'ag-starter-companion' ), array( $this, 'avocat_domaine_metabox_render' ), 'ag_domaine', 'side', 'default' );
	}

	public function avocat_domaine_metabox_render( $post ) {
		wp_nonce_field( 'ag_domaine_meta_save', 'ag_domaine_meta_nonce' );
		$icon     = get_post_meta( $post->ID, '_ag_domaine_icon', true );
		$examples = get_post_meta( $post->ID, '_ag_domaine_examples', true );
		echo '<p><label for="ag_domaine_icon"><strong>' . esc_html__( 'Icône', 'ag-starter-companion' ) . '</strong></label><br>';
		echo '<input type="text" id="ag_domaine_icon" name="ag_domaine_icon" value="' . esc_attr( $icon ) . '" maxlength="20" style="width:160px;text-align:center;" placeholder="scales"><br>';
		echo '<small>' . esc_html__( 'Mots-clés : scales, gavel, shield, briefcase, house, family, document, heart, lock, bank. Sinon emoji.', 'ag-starter-companion' ) . '</small></p>';
		echo '<p><label for="ag_domaine_examples"><strong>' . esc_html__( 'Exemples de cas traités', 'ag-starter-companion' ) . '</strong></label><br>';
		echo '<textarea id="ag_domaine_examples" name="ag_domaine_examples" rows="4" style="width:100%;">' . esc_textarea( $examples ) . '</textarea><br>';
		echo '<small>' . esc_html__( '1 ligne par exemple.', 'ag-starter-companion' ) . '</small></p>';
	}

	public function avocat_domaine_save_meta( $post_id ) {
		if ( ! isset( $_POST['ag_domaine_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ag_domaine_meta_nonce'] ) ), 'ag_domaine_meta_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		if ( isset( $_POST['ag_domaine_icon'] ) ) {
			update_post_meta( $post_id, '_ag_domaine_icon', sanitize_text_field( wp_unslash( $_POST['ag_domaine_icon'] ) ) );
		}
		if ( isset( $_POST['ag_domaine_examples'] ) ) {
			update_post_meta( $post_id, '_ag_domaine_examples', sanitize_textarea_field( wp_unslash( $_POST['ag_domaine_examples'] ) ) );
		}
	}

	/**
	 * Return the slug of the currently active supported theme (parent or stylesheet),
	 * or an empty string if no AG Starter theme is active.
	 *
	 * @return string
	 */
	public function get_active_theme_slug() {
		$theme    = wp_get_theme();
		$template = $theme->get_template();     // parent theme
		$stylesh  = $theme->get_stylesheet();   // child theme if any
		$supported = array( 'ag-starter-restaurant', 'ag-starter-artisan', 'ag-starter-coach', 'ag-starter-avocat', 'ag-starter-barber' );
		foreach ( array( $stylesh, $template ) as $candidate ) {
			if ( in_array( $candidate, $supported, true ) ) {
				return $candidate;
			}
		}
		return '';
	}

	/**
	 * Données d'import (pages, menu, réglages) par thème AG Starter.
	 */
	public function get_theme_data_map() {
		return array(
			'ag-starter-restaurant' => array(
				'name'  => 'AG Starter Restaurant',
				'pages' => array(
					'accueil'     => array(
						'title'   => __( 'Accueil', 'ag-starter-companion' ),
						'content' => '<!-- Rendu par front-page.php -->',
					),
					'carte'       => array(
						'title'   => __( 'Notre carte', 'ag-starter-companion' ),
						'content' => __( 'Presentez vos entrees, plats, desserts, formules du midi et du soir.', 'ag-starter-companion' ),
					),
					'reservation' => array(
						'title'   => __( 'Reservation', 'ag-starter-companion' ),
						'content' => __( 'Reservez votre table en ligne ou contactez-nous au 01 23 45 67 89.', 'ag-starter-companion' ),
					),
					'a-propos'    => array(
						'title'   => __( 'A propos', 'ag-starter-companion' ),
						'content' => __( 'Racontez l\'histoire de votre restaurant, vos valeurs, votre equipe.', 'ag-starter-companion' ),
					),
					'contact'     => array(
						'title'   => __( 'Contact', 'ag-starter-companion' ),
						'content' => __( 'Adresse, horaires, telephone, email et plan d\'acces.', 'ag-starter-companion' ),
					),
				),
			),
			'ag-starter-artisan'    => array(
				'name'  => 'AG Starter Artisan',
				'pages' => array(
					'accueil'      => array(
						'title'   => __( 'Accueil', 'ag-starter-companion' ),
						'content' => '<!-- Rendu par front-page.php -->',
					),
					'prestations'  => array(
						'title'   => __( 'Nos prestations', 'ag-starter-companion' ),
						'content' => __( 'Detaillez vos services : renovation, installation, entretien, depannage.', 'ag-starter-companion' ),
					),
					'realisations' => array(
						'title'   => __( 'Nos realisations', 'ag-starter-companion' ),
						'content' => __( 'Galerie de vos chantiers realises avec photos avant/apres.', 'ag-starter-companion' ),
					),
					'a-propos'     => array(
						'title'   => __( 'A propos', 'ag-starter-companion' ),
						'content' => __( 'Votre entreprise, vos qualifications, votre equipe, vos engagements.', 'ag-starter-companion' ),
					),
					'contact'      => array(
						'title'   => __( 'Contact', 'ag-starter-companion' ),
						'content' => __( 'Adresse, telephone, email, zones d\'intervention et formulaire de devis.', 'ag-starter-companion' ),
					),
				),
			),
			'ag-starter-coach'      => array(
				'name'  => 'AG Starter Coach',
				'pages' => array(
					'accueil'         => array(
						'title'   => __( 'Accueil', 'ag-starter-companion' ),
						'content' => '<!-- Rendu par front-page.php -->',
					),
					'accompagnements' => array(
						'title'   => __( 'Mes accompagnements', 'ag-starter-companion' ),
						'content' => __( 'Coaching individuel, seances de groupe, ateliers, formations.', 'ag-starter-companion' ),
					),
					'temoignages'     => array(
						'title'   => __( 'Temoignages', 'ag-starter-companion' ),
						'content' => __( 'Les retours de vos clients, leurs transformations, leurs resultats.', 'ag-starter-companion' ),
					),
					'a-propos'        => array(
						'title'   => __( 'A propos', 'ag-starter-companion' ),
						'content' => __( 'Votre parcours, vos certifications, votre approche.', 'ag-starter-companion' ),
					),
					'contact'         => array(
						'title'   => __( 'Contact', 'ag-starter-companion' ),
						'content' => __( 'Prise de rendez-vous, cabinet, visio, telephone, email.', 'ag-starter-companion' ),
					),
				),
			),
			'ag-starter-avocat'     => array(
				'name'  => 'AG Starter Avocat',
				'pages' => array(
					'accueil'      => array(
						'title'   => __( 'Accueil', 'ag-starter-companion' ),
						'content' => '<!-- Rendu par front-page.php -->',
					),
					'expertise'    => array(
						'title'   => __( 'Domaines d\'expertise', 'ag-starter-companion' ),
						'content' => __( 'Droit des affaires, droit du travail, droit de la famille, droit immobilier.', 'ag-starter-companion' ),
					),
					'honoraires'   => array(
						'title'   => __( 'Honoraires', 'ag-starter-companion' ),
						'content' => __( 'Premier rendez-vous, forfaits, honoraires au temps passe ou de resultat.', 'ag-starter-companion' ),
					),
					'cabinet'      => array(
						'title'   => __( 'Le cabinet', 'ag-starter-companion' ),
						'content' => __( 'Presentez votre cabinet, votre histoire, vos engagements deontologiques.', 'ag-starter-companion' ),
					),
					'rendez-vous'  => array(
						'title'   => __( 'Prendre rendez-vous', 'ag-starter-companion' ),
						'content' => __( 'Consultation au cabinet ou en visio. Reservation en ligne, telephone, email.', 'ag-starter-companion' ),
					),
				),
			),
			'ag-starter-barber'     => array(
				'name'  => 'AG Starter Barber',
				'pages' => array(
					'accueil'  => array(
						'title'   => __( 'Accueil', 'ag-starter-companion' ),
						'content' => '<!-- Rendu par front-page.php -->',
					),
					'tarifs'   => array(
						'title'   => __( 'Nos tarifs', 'ag-starter-companion' ),
						'content' => __( 'Coupes homme, barbe, degradé, enfant. Tarifs fixes, pas de surprise.', 'ag-starter-companion' ),
					),
					'a-propos' => array(
						'title'   => __( 'Le salon', 'ag-starter-companion' ),
						'content' => __( 'Notre equipe de barbers, notre histoire, nos valeurs.', 'ag-starter-companion' ),
					),
					'contact'  => array(
						'title'   => __( 'Contact', 'ag-starter-companion' ),
						'content' => __( 'Adresse, horaires, telephone. Pas de rendez-vous, venez quand vous voulez.', 'ag-starter-companion' ),
					),
				),
			),
		);
	}

	/**
	 * Register the admin page under Appearance.
	 */
	public function register_admin_page() {
		if ( ! $this->get_active_theme_slug() ) {
			return;
		}
		add_theme_page(
			esc_html__( 'Configuration AG Starter', 'ag-starter-companion' ),
			esc_html__( 'Configuration AG', 'ag-starter-companion' ),
			'manage_options',
			'ag-starter-companion',
			array( $this, 'render_admin_page' )
		);
	}

	/**
	 * Admin notice prompting users to open the setup page.
	 */
	public function admin_notice() {
		$slug = $this->get_active_theme_slug();
		if ( ! $slug || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( get_option( 'ag_starter_companion_done_' . $slug ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( $screen && 'appearance_page_ag-starter-companion' === $screen->id ) {
			return;
		}
		$url  = admin_url( 'themes.php?page=ag-starter-companion' );
		$map  = $this->get_theme_data_map();
		$name = isset( $map[ $slug ] ) ? $map[ $slug ]['name'] : 'AG Starter';
		echo '<div class="notice notice-info is-dismissible"><p><strong>' . esc_html( $name ) . '</strong> &mdash; ';
		esc_html_e( 'Cliquez ici pour importer le contenu demo en un clic :', 'ag-starter-companion' );
		echo ' <a href="' . esc_url( $url ) . '" class="button button-primary" style="margin-left:8px;">';
		esc_html_e( 'Lancer la configuration', 'ag-starter-companion' );
		echo '</a></p></div>';
	}

	/**
	 * Render the setup page.
	 */
	public function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$slug = $this->get_active_theme_slug();
		if ( ! $slug ) {
			return;
		}
		$map  = $this->get_theme_data_map();
		$data = isset( $map[ $slug ] ) ? $map[ $slug ] : array();
		$name = isset( $data['name'] ) ? $data['name'] : 'AG Starter';

		// Handle actions.
		if ( isset( $_POST['ag_do_import'] ) && check_admin_referer( 'ag_starter_companion_import' ) ) {
			$report = $this->run_import( $slug );
			update_option( 'ag_starter_companion_done_' . $slug, time() );
			echo '<div class="notice notice-success"><p><strong>' . esc_html__( 'Import termine avec succes.', 'ag-starter-companion' ) . '</strong></p><ul style="list-style:disc;padding-left:20px;">';
			foreach ( $report as $line ) {
				echo '<li>' . esc_html( $line ) . '</li>';
			}
			echo '</ul><p><a href="' . esc_url( home_url( '/' ) ) . '" class="button button-primary" target="_blank">' . esc_html__( 'Voir le site', 'ag-starter-companion' ) . ' &rarr;</a></p></div>';
		}
		if ( isset( $_POST['ag_do_reset'] ) && check_admin_referer( 'ag_starter_companion_reset' ) ) {
			$this->run_reset( $slug );
			delete_option( 'ag_starter_companion_done_' . $slug );
			echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'Contenu demo supprime.', 'ag-starter-companion' ) . '</strong></p></div>';
		}
		if ( isset( $_POST['ag_do_cleanup'] ) && check_admin_referer( 'ag_starter_companion_cleanup' ) ) {
			$report = $this->run_cleanup( $slug );
			update_option( 'ag_starter_companion_done_' . $slug, time() );
			echo '<div class="notice notice-success"><p><strong>' . esc_html__( 'Nettoyage termine.', 'ag-starter-companion' ) . '</strong></p><ul style="list-style:disc;padding-left:20px;">';
			foreach ( $report as $line ) {
				echo '<li>' . esc_html( $line ) . '</li>';
			}
			echo '</ul><p><a href="' . esc_url( home_url( '/' ) ) . '" class="button button-primary" target="_blank">' . esc_html__( 'Voir le site', 'ag-starter-companion' ) . ' &rarr;</a></p></div>';
		}

		$done = (int) get_option( 'ag_starter_companion_done_' . $slug, 0 );
		?>
		<div class="wrap">
			<h1><?php echo esc_html( sprintf( __( 'Configuration — %s', 'ag-starter-companion' ), $name ) ); ?></h1>

			<div style="max-width:780px;margin-top:20px;padding:24px;background:#fff;border:1px solid #ccd0d4;border-left:4px solid #D4B45C;">
				<h2 style="margin-top:0;"><?php esc_html_e( 'Import en un clic', 'ag-starter-companion' ); ?></h2>
				<p><?php esc_html_e( 'Cliquez sur le bouton ci-dessous pour installer automatiquement :', 'ag-starter-companion' ); ?></p>
				<ul style="list-style:disc;padding-left:20px;">
					<?php if ( isset( $data['pages'] ) ) : ?>
						<li>
							<?php
							$titles = array_map(
								static function ( $p ) {
									return $p['title'];
								},
								$data['pages']
							);
							echo esc_html( sprintf(
								/* translators: 1: number of pages, 2: list of page titles. */
								__( '%1$d pages creees : %2$s', 'ag-starter-companion' ),
								count( $titles ),
								implode( ', ', $titles )
							) );
							?>
						</li>
					<?php endif; ?>
					<li><?php esc_html_e( 'Menu principal cree et assigne automatiquement', 'ag-starter-companion' ); ?></li>
					<li><?php esc_html_e( 'Page d\'accueil definie (template front-page.php)', 'ag-starter-companion' ); ?></li>
					<li><?php esc_html_e( 'Permaliens actives (/%postname%/)', 'ag-starter-companion' ); ?></li>
				</ul>
				<p><em><?php esc_html_e( 'L\'import est 100% local : aucune connexion internet n\'est necessaire.', 'ag-starter-companion' ); ?></em></p>

				<?php if ( $done ) : ?>
					<p style="padding:12px;background:#e7f5e9;border-left:4px solid #28a745;">
						<strong><?php esc_html_e( 'Contenu demo deja importe.', 'ag-starter-companion' ); ?></strong><br>
						<?php
						printf(
							/* translators: %s: human-readable date. */
							esc_html__( 'Derniere execution : %s', 'ag-starter-companion' ),
							esc_html( wp_date( 'd/m/Y H:i', $done ) )
						);
						?>
					</p>
				<?php endif; ?>

				<form method="post" style="display:inline-block;margin-right:12px;">
					<?php wp_nonce_field( 'ag_starter_companion_import' ); ?>
					<button type="submit" name="ag_do_import" class="button button-primary button-hero">
						<?php echo $done ? esc_html__( 'Relancer l\'import', 'ag-starter-companion' ) : esc_html__( 'Importer le contenu demo', 'ag-starter-companion' ); ?>
					</button>
				</form>

				<?php if ( $done ) : ?>
					<form method="post" style="display:inline-block;" onsubmit="return confirm('<?php echo esc_js( __( 'Supprimer definitivement le contenu demo ?', 'ag-starter-companion' ) ); ?>');">
						<?php wp_nonce_field( 'ag_starter_companion_reset' ); ?>
						<button type="submit" name="ag_do_reset" class="button">
							<?php esc_html_e( 'Reinitialiser', 'ag-starter-companion' ); ?>
						</button>
					</form>
				<?php endif; ?>

				<form method="post" style="display:inline-block;margin-left:12px;" onsubmit="return confirm('<?php echo esc_js( __( 'Mettre a la corbeille les pages des AUTRES themes et reconstruire un menu propre pour ce theme ?', 'ag-starter-companion' ) ); ?>');">
					<?php wp_nonce_field( 'ag_starter_companion_cleanup' ); ?>
					<button type="submit" name="ag_do_cleanup" class="button">
						🧹 <?php esc_html_e( 'Nettoyer (pages/menus d\'autres themes)', 'ag-starter-companion' ); ?>
					</button>
				</form>
				<p style="margin-top:10px;color:#777;font-size:.92em;max-width:780px;">
					<?php esc_html_e( 'Utile si vous avez teste plusieurs templates sur ce site : met a la corbeille les pages des autres themes (Coach, Barber...), supprime les menus parasites et reconstruit le menu de CE theme avec ses propres pages.', 'ag-starter-companion' ); ?>
				</p>
			</div>

			<div style="max-width:780px;margin-top:20px;padding:24px;background:#f8f9fa;border:1px solid #ddd;">
				<h3 style="margin-top:0;"><?php esc_html_e( 'Besoin d\'aide ?', 'ag-starter-companion' ); ?></h3>
				<p>
					<?php
					printf(
						/* translators: %s: link to contact page. */
						wp_kses(
							__( 'Ce plugin est offert par AGthèmes (Alliance Group). Si vous bloquez sur la personnalisation ou voulez un site plus avance, %s et on vous aide gratuitement a demarrer.', 'ag-starter-companion' ),
							array( 'a' => array( 'href' => array(), 'target' => array(), 'rel' => array() ) )
						),
						'<a href="https://alliancegroupe-inc.com/contact" target="_blank" rel="noopener">' . esc_html__( 'contactez-nous', 'ag-starter-companion' ) . '</a>'
					);
					?>
				</p>
				<p>
					<a href="https://alliancegroupe-inc.com/templates-wordpress" target="_blank" rel="noopener">
						<?php esc_html_e( 'Decouvrir d\'autres templates gratuits', 'ag-starter-companion' ); ?> &rarr;
					</a>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Run the import for the given theme slug.
	 *
	 * @param string $slug Theme slug.
	 * @return array
	 */
	/**
	 * Re-import auto a chaque MAJ du Companion : detecte le slug du
	 * theme actif (ag-starter-avocat, restaurant, artisan, coach,
	 * barber) et relance run_import si la version stockee differe.
	 */
	public function maybe_auto_reimport() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$theme = wp_get_theme();
		$slug  = $theme->get_template();
		$known = array( 'ag-starter-avocat', 'ag-starter-restaurant', 'ag-starter-artisan', 'ag-starter-coach', 'ag-starter-barber' );
		if ( ! in_array( $slug, $known, true ) ) return;
		$key  = 'ag_companion_imported_' . $slug;
		$cur  = AG_STARTER_COMPANION_VERSION;
		$prev = get_option( $key, '' );
		if ( $prev === $cur ) return;
		// Ne lance que si l'import initial a deja ete fait (sinon on
		// laisse le user cliquer manuellement la 1ere fois).
		if ( ! $prev ) {
			update_option( $key, $cur );
			return;
		}
		$this->run_import( $slug );
		update_option( $key, $cur );
		set_transient( 'ag_companion_just_updated_from', $prev, 60 );
	}

	/**
	 * Separation des menus par theme.
	 *
	 * Les emplacements de menu sont partages au niveau du site : quand on
	 * teste plusieurs themes (avocat, coach...) sur une meme install, le
	 * menu d'un theme peut rester assigne a l'emplacement "primary" d'un
	 * autre -> contenus melanges (ex. items Coach affiches sur Avocat).
	 *
	 * Ici on verifie que le menu assigne a "primary" appartient BIEN au
	 * theme actif (au moins une de ses pages). Sinon on relance run_import
	 * pour ce theme : il (re)cree le menu "Menu principal AG" avec les pages
	 * du theme actif et l'assigne -> chaque theme a son menu propre.
	 *
	 * Idempotent : une fois le bon menu assigne, la condition est satisfaite
	 * et on ne relance plus rien (pas de boucle). Respecte un menu custom du
	 * client tant qu'il contient au moins une page du theme.
	 */
	public function maybe_fix_theme_menu() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$theme = wp_get_theme();
		$slug  = $theme->get_template();
		$map   = $this->get_theme_data_map();
		if ( ! isset( $map[ $slug ] ) ) {
			return;
		}

		// Slugs de pages attendus pour ce theme (hors accueil).
		$expected = array_diff( array_keys( $map[ $slug ]['pages'] ), array( 'accueil' ) );
		if ( empty( $expected ) ) {
			return;
		}

		$locations = (array) get_theme_mod( 'nav_menu_locations' );
		$menu_id   = isset( $locations['primary'] ) ? (int) $locations['primary'] : 0;

		$matches = false;
		if ( $menu_id && wp_get_nav_menu_object( $menu_id ) ) {
			$items = wp_get_nav_menu_items( $menu_id );
			if ( $items ) {
				foreach ( $items as $item ) {
					if ( 'post_type' === $item->type && 'page' === $item->object ) {
						$p = get_post( (int) $item->object_id );
						if ( $p && in_array( $p->post_name, $expected, true ) ) {
							$matches = true;
							break;
						}
					}
				}
			}
		}

		if ( $matches ) {
			return; // Le menu assigne appartient bien au theme actif.
		}

		// Menu absent, vide ou d'un autre theme -> on (re)construit celui du
		// theme actif et on l'assigne.
		$this->run_import( $slug );
		update_option( 'ag_starter_companion_done_' . $slug, time() );
	}

	public function run_import( $slug ) {
		$log = array();
		$map = $this->get_theme_data_map();
		if ( ! isset( $map[ $slug ] ) ) {
			return $log;
		}
		$pages = $map[ $slug ]['pages'];

		$page_ids = array();
		foreach ( $pages as $slug_key => $data ) {
			$existing = get_page_by_path( $slug_key );
			if ( $existing ) {
				$page_ids[ $slug_key ] = $existing->ID;
				$log[]                 = sprintf( 'Page existante conservee : %s', $data['title'] );
				continue;
			}
			$id = wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => $data['title'],
					'post_name'    => $slug_key,
					'post_content' => $data['content'],
				)
			);
			if ( ! is_wp_error( $id ) && $id ) {
				$page_ids[ $slug_key ] = $id;
				$log[]                 = sprintf( 'Page creee : %s', $data['title'] );
			}
		}

		if ( isset( $page_ids['accueil'] ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $page_ids['accueil'] );
			$log[] = 'Page d\'accueil configuree';
		}

		$menu_name = 'Menu principal AG';
		$menu      = wp_get_nav_menu_object( $menu_name );
		$menu_id   = false;
		if ( ! $menu ) {
			$menu_id = wp_create_nav_menu( $menu_name );
		} else {
			$menu_id = $menu->term_id;
			$items   = wp_get_nav_menu_items( $menu_id );
			if ( $items ) {
				foreach ( $items as $item ) {
					wp_delete_post( $item->ID, true );
				}
			}
		}

		if ( $menu_id && ! is_wp_error( $menu_id ) ) {
			foreach ( $page_ids as $slug_key => $id ) {
				if ( $slug_key === 'accueil' ) {
					continue;
				}
				wp_update_nav_menu_item( $menu_id, 0, array(
					'menu-item-title'     => $pages[ $slug_key ]['title'],
					'menu-item-object'    => 'page',
					'menu-item-object-id' => $id,
					'menu-item-type'      => 'post_type',
					'menu-item-status'    => 'publish',
				) );
			}
			$locations            = get_theme_mod( 'nav_menu_locations' );
			$locations['primary'] = $menu_id;
			set_theme_mod( 'nav_menu_locations', $locations );
			$log[] = 'Menu principal cree et assigne';
		}

		// Theme-specific extras : Avocat ships demo Domaines d'expertise
		// via the ag_domaine CPT registered by the theme itself.
		if ( 'ag-starter-avocat' === $slug && post_type_exists( 'ag_domaine' ) ) {
			$created = $this->import_avocat_domaines();
			if ( $created ) {
				$log[] = sprintf( '%d domaines d\'expertise crees', $created );
			}
		}

		if ( '' === get_option( 'permalink_structure' ) ) {
			update_option( 'permalink_structure', '/%postname%/' );
			flush_rewrite_rules();
			$log[] = 'Permaliens actives';
		}

		return $log;
	}

	/**
	 * Import a starter set of Domaines d'expertise (Avocat CPT).
	 *
	 * Only runs when the active theme is ag-starter-avocat and the CPT
	 * is already registered. Skips any domaine whose slug already exists
	 * so the import is idempotent.
	 *
	 * @return int Number of domaines effectively created.
	 */
	public function import_avocat_domaines() {
		$domaines = array(
			array(
				'slug'    => 'droit-des-affaires',
				'title'   => __( 'Droit des affaires', 'ag-starter-companion' ),
				'icon'    => '💼',
				'excerpt' => __( 'Conseil et representation des entreprises : creation, contrats commerciaux, contentieux, restructuration.', 'ag-starter-companion' ),
				'content' => __( 'Notre cabinet accompagne les dirigeants et les entreprises a chaque etape de leur vie : creation et choix de la structure, redaction et negociation de contrats commerciaux, mise en place de partenariats, contentieux commerciaux, restructuration et procedures collectives.', 'ag-starter-companion' ),
				'examples' => "Creation et statuts de societes\nNegociation de baux commerciaux\nLitiges entre associes\nProcedures de recouvrement\nMise en conformite RGPD",
				'order'   => 1,
			),
			array(
				'slug'    => 'droit-du-travail',
				'title'   => __( 'Droit du travail', 'ag-starter-companion' ),
				'icon'    => '👔',
				'excerpt' => __( 'Defense des salaries et des employeurs : licenciements, contrats, harcelement, ruptures conventionnelles.', 'ag-starter-companion' ),
				'content' => __( 'Que vous soyez salarie ou employeur, nous defendons vos droits avec rigueur. Contestation de licenciement, negociation de rupture conventionnelle, dossiers prud\'homaux, harcelement moral ou sexuel : nous batissons avec vous une strategie adaptee.', 'ag-starter-companion' ),
				'examples' => "Contestation de licenciement\nRupture conventionnelle\nHarcelement moral / sexuel\nNegociation salariale\nProcedure prud\'homale",
				'order'   => 2,
			),
			array(
				'slug'    => 'droit-de-la-famille',
				'title'   => __( 'Droit de la famille', 'ag-starter-companion' ),
				'icon'    => '👨‍👩‍👧',
				'excerpt' => __( 'Divorce, garde d\'enfants, succession, adoption, regimes matrimoniaux. Discretion et empathie garanties.', 'ag-starter-companion' ),
				'content' => __( 'Le droit de la famille touche a l\'intime. Notre approche allie expertise juridique et ecoute bienveillante. Nous traitons les divorces (par consentement mutuel ou contentieux), les pensions alimentaires, les questions de garde et de droit de visite, ainsi que les successions complexes.', 'ag-starter-companion' ),
				'examples' => "Divorce par consentement mutuel\nDivorce contentieux\nGarde d\'enfants et droit de visite\nPensions alimentaires\nSuccession et heritage",
				'order'   => 3,
			),
			array(
				'slug'    => 'droit-immobilier',
				'title'   => __( 'Droit immobilier', 'ag-starter-companion' ),
				'icon'    => '🏠',
				'excerpt' => __( 'Acquisition, vente, copropriete, baux, troubles de voisinage, vices caches.', 'ag-starter-companion' ),
				'content' => __( 'L\'immobilier represente un investissement majeur. Nous accompagnons proprietaires et locataires dans toutes les problematiques : redaction et contestation de baux, copropriete, troubles du voisinage, vices caches, expropriation, urbanisme.', 'ag-starter-companion' ),
				'examples' => "Litiges de copropriete\nContestation de bail\nTroubles de voisinage\nVices caches a l\'achat\nProcedure d\'expulsion",
				'order'   => 4,
			),
			array(
				'slug'    => 'droit-penal',
				'title'   => __( 'Droit penal', 'ag-starter-companion' ),
				'icon'    => '⚖️',
				'excerpt' => __( 'Defense penale 24/7. Garde a vue, plaintes, comparution immediate, instruction.', 'ag-starter-companion' ),
				'content' => __( 'En matiere penale, l\'urgence et la confidentialite sont essentielles. Nous intervenons des la garde a vue, depot de plainte, comparution immediate, instruction et audience de jugement. Defense ferme et personnalisee.', 'ag-starter-companion' ),
				'examples' => "Garde a vue (intervention 24/7)\nDepot de plainte\nComparution immediate\nDefense en cour d\'assises\nVictimes d\'infractions",
				'order'   => 5,
			),
			array(
				'slug'    => 'droit-fiscal',
				'title'   => __( 'Droit fiscal', 'ag-starter-companion' ),
				'icon'    => '📊',
				'excerpt' => __( 'Optimisation, controle fiscal, contentieux, declarations, ISF, donations et successions.', 'ag-starter-companion' ),
				'content' => __( 'Le droit fiscal est en constante evolution. Nous vous accompagnons dans vos choix patrimoniaux, vos declarations, et vous defendons en cas de controle ou de contentieux fiscal. Optimisation legale et securisation de votre patrimoine.', 'ag-starter-companion' ),
				'examples' => "Controle fiscal\nContentieux fiscal\nOptimisation patrimoniale\nDonations / successions\nDeclaration ISF / IFI",
				'order'   => 6,
			),
		);

		$created = 0;
		foreach ( $domaines as $d ) {
			$existing = get_posts(
				array(
					'name'           => $d['slug'],
					'post_type'      => 'ag_domaine',
					'post_status'    => array( 'publish', 'draft', 'future', 'pending', 'private' ),
					'posts_per_page' => 1,
				)
			);
			if ( $existing ) {
				continue;
			}
			$id = wp_insert_post(
				array(
					'post_type'    => 'ag_domaine',
					'post_status'  => 'publish',
					'post_title'   => $d['title'],
					'post_name'    => $d['slug'],
					'post_excerpt' => $d['excerpt'],
					'post_content' => $d['content'],
					'menu_order'   => $d['order'],
				)
			);
			if ( ! is_wp_error( $id ) && $id ) {
				update_post_meta( $id, '_ag_domaine_icon', $d['icon'] );
				update_post_meta( $id, '_ag_domaine_examples', $d['examples'] );
				$created++;
			}
		}
		return $created;
	}

	/**
	 * Nettoyage multi-themes : met a la corbeille les pages appartenant aux
	 * AUTRES themes (Coach, Barber...), supprime les menus parasites, puis
	 * reconstruit un menu propre pour le theme actif via run_import().
	 *
	 * Sert quand on a teste plusieurs templates sur une meme install et que
	 * pages/menus se sont melanges.
	 *
	 * @param string $slug Theme slug actif.
	 * @return array Journal des operations.
	 */
	public function run_cleanup( $slug ) {
		$log = array();
		$map = $this->get_theme_data_map();
		if ( ! isset( $map[ $slug ] ) ) {
			return $log;
		}

		// Slugs a conserver (pages du theme actif) + pages partagees utiles.
		$keep = array_map( 'sanitize_title', array_keys( $map[ $slug ]['pages'] ) );
		$keep = array_merge( $keep, array( 'contact' ) );

		// Slugs des autres themes, candidats a suppression.
		$foreign = array();
		foreach ( $map as $other_slug => $other_data ) {
			if ( $other_slug === $slug ) {
				continue;
			}
			foreach ( array_keys( $other_data['pages'] ) as $page_slug ) {
				$foreign[ sanitize_title( $page_slug ) ] = true;
			}
		}
		// Quelques orphelins connus (anciennes versions / pages manuelles).
		foreach ( array( 'modes-de-seance', 'le-salon', 'tarifs', 'nos-tarifs' ) as $orphan ) {
			$foreign[ $orphan ] = true;
		}
		// Ne jamais supprimer une page conservee.
		foreach ( $keep as $page_slug ) {
			unset( $foreign[ $page_slug ] );
		}

		// Mots-cles de titres typiques des AUTRES themes (coach/barber).
		// Assez specifiques pour ne pas toucher les pages business/legales.
		$title_kw = '/(accompagnement|séance|seance|salon|barber|coiffeur|témoignage|temoignage)/iu';

		// 1) Corbeille des pages d'autres themes (y compris les doublons
		//    "slug-2", "slug-3" et les pages reperees par leur titre).
		$pages = get_posts( array(
			'post_type'   => 'page',
			'numberposts' => -1,
			'post_status' => 'any',
			'suppress_filters' => true,
		) );
		foreach ( (array) $pages as $page ) {
			$base = preg_replace( '/-\d+$/', '', $page->post_name );
			if ( in_array( $base, $keep, true ) ) {
				continue; // page du theme actif / partagee -> on garde.
			}
			$is_foreign = isset( $foreign[ $base ] ) || (bool) preg_match( $title_kw, $page->post_title );
			if ( $is_foreign ) {
				wp_trash_post( $page->ID );
				/* translators: %s: page title. */
				$log[] = sprintf( __( 'Page d\'un autre theme mise a la corbeille : %s', 'ag-starter-companion' ), $page->post_title );
			}
		}

		// 2) Supprime les menus parasites (tout sauf "Menu principal AG",
		//    qui sera reconstruit juste apres pour le theme actif).
		$menus = wp_get_nav_menus();
		foreach ( (array) $menus as $menu ) {
			if ( 'Menu principal AG' !== $menu->name ) {
				wp_delete_nav_menu( $menu->term_id );
				/* translators: %s: menu name. */
				$log[] = sprintf( __( 'Menu parasite supprime : %s', 'ag-starter-companion' ), $menu->name );
			}
		}

		// 3) Reconstruit le menu propre du theme actif + reassignation.
		$log = array_merge( $log, $this->run_import( $slug ) );

		if ( empty( $log ) ) {
			$log[] = __( 'Rien a nettoyer : aucune page/menu d\'un autre theme trouve.', 'ag-starter-companion' );
		}

		return $log;
	}

	/**
	 * Reset the demo content for the given theme slug.
	 *
	 * @param string $slug Theme slug.
	 */
	public function run_reset( $slug ) {
		$map = $this->get_theme_data_map();
		if ( ! isset( $map[ $slug ] ) ) {
			return;
		}
		foreach ( array_keys( $map[ $slug ]['pages'] ) as $page_slug ) {
			$p = get_page_by_path( $page_slug );
			if ( $p ) {
				wp_delete_post( $p->ID, true );
			}
		}
		$menu = wp_get_nav_menu_object( 'Menu principal AG' );
		if ( $menu ) {
			wp_delete_nav_menu( $menu->term_id );
		}
		update_option( 'show_on_front', 'posts' );
		update_option( 'page_on_front', 0 );

		// Theme-specific cleanup : delete demo avocat domaines.
		if ( 'ag-starter-avocat' === $slug && post_type_exists( 'ag_domaine' ) ) {
			$demo_slugs = array(
				'droit-des-affaires', 'droit-du-travail', 'droit-de-la-famille',
				'droit-immobilier', 'droit-penal', 'droit-fiscal',
			);
			foreach ( $demo_slugs as $demo_slug ) {
				$found = get_posts(
					array(
						'name'           => $demo_slug,
						'post_type'      => 'ag_domaine',
						'post_status'    => array( 'publish', 'draft', 'private' ),
						'posts_per_page' => 1,
					)
				);
				if ( $found ) {
					wp_delete_post( $found[0]->ID, true );
				}
			}
		}
	}

	// ═══════════════════════════════════════════════════════════════
	// AUTO-UPDATE PREFERENCE + UPDATE NOTIFICATION
	// ═══════════════════════════════════════════════════════════════

	/**
	 * Auto-approve updates for this plugin (opt-in by default).
	 */
}

new AG_Starter_Companion();
