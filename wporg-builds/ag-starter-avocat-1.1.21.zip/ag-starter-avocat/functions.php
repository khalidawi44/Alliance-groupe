<?php
/**
 * AG Starter Avocat functions and definitions.
 *
 * @package AG_Starter_Avocat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'ag_starter_avocat_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 */
	function ag_starter_avocat_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 */
		load_theme_textdomain( 'ag-starter-avocat', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		// Let WordPress manage the document title.
		add_theme_support( 'title-tag' );

		// Enable support for Post Thumbnails on posts and pages.
		add_theme_support( 'post-thumbnails' );

		// Switch default core markup to output valid HTML5.
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
				'navigation-widgets',
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		// Add support for core custom logo.
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 60,
				'width'       => 200,
				'flex-height' => true,
				'flex-width'  => true,
			)
		);

		// Add support for custom background.
		add_theme_support(
			'custom-background',
			array(
				'default-color' => '0a0a0a',
			)
		);

		// Add support for responsive embeds.
		add_theme_support( 'responsive-embeds' );

		// Add support for wide and full alignment.
		add_theme_support( 'align-wide' );

		// Styles par défaut des blocs Gutenberg + styles de l'éditeur.
		add_theme_support( 'wp-block-styles' );
		add_editor_style( 'style.css' );

		// Image d'en-tête personnalisable.
		add_theme_support(
			'custom-header',
			array(
				'default-image' => '',
				'width'         => 1920,
				'height'        => 600,
				'flex-width'    => true,
				'flex-height'   => true,
				'header-text'   => false,
			)
		);

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'primary' => esc_html__( 'Main menu', 'ag-starter-avocat' ),
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'ag_starter_avocat_setup' );

/**
 * Menu de secours : si AUCUN menu n'est assigne a l'emplacement "primary"
 * (ce qui arrive a chaque changement de theme, les emplacements etant lies
 * au theme actif), on liste automatiquement les pages du site. Ainsi le
 * menu n'est JAMAIS vide — il suffira ensuite, si on veut, de creer un menu
 * sur-mesure dans Apparence > Menus.
 */
if ( ! function_exists( 'ag_starter_avocat_menu_fallback' ) ) :
	function ag_starter_avocat_menu_fallback() {
		// On exclut les pages utilitaires (legal, e-commerce) qui n'ont rien
		// a faire dans le menu principal, puis on limite a 5 onglets pour
		// rester epure.
		$exclude_slugs = array(
			'mentions-legales', 'politique-de-confidentialite', 'confidentialite',
			'politique-de-cookies', 'cookies', 'cgv', 'cgu', 'conditions-generales',
			'plan-du-site', 'panier', 'commande', 'mon-compte', 'checkout', 'cart',
			'my-account', 'livraison', 'retours', 'remboursement',
		);
		$exclude_ids = array();
		foreach ( $exclude_slugs as $slug ) {
			$p = get_page_by_path( $slug );
			if ( $p ) {
				$exclude_ids[] = $p->ID;
			}
		}
		$pages = wp_list_pages( array(
			'echo'        => false,
			'title_li'    => '',
			'depth'       => 1,
			'sort_column' => 'menu_order, post_title',
			'number'      => 5,
			'exclude'     => implode( ',', $exclude_ids ),
		) );
		if ( $pages ) {
			echo '<ul class="ag-primary-menu">' . $pages . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		// Aucune Page reelle (import de contenu pas encore lance) : on affiche
		// un menu par defaut pointant vers les sections standard du cabinet,
		// pour que le menu ne soit JAMAIS vide.
		$defaults = array(
			''            => __( 'Home', 'ag-starter-avocat' ),
			'expertise'   => __( "Practice areas", 'ag-starter-avocat' ),
			'honoraires'  => __( 'Fees', 'ag-starter-avocat' ),
			'cabinet'     => __( 'The firm', 'ag-starter-avocat' ),
			'rendez-vous' => __( 'Book an appointment', 'ag-starter-avocat' ),
		);
		echo '<ul class="ag-primary-menu">';
		foreach ( $defaults as $slug => $label ) {
			$url = $slug ? home_url( '/' . $slug . '/' ) : home_url( '/' );
			echo '<li class="menu-item"><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></li>';
		}
		echo '</ul>';
	}
endif;

/**
 * Helper: read a Customizer option (alias for ag_starter_avocat_get_option
 * with a runtime fallback default for safety).
 */
if ( ! function_exists( 'ag_avocat_opt' ) ) {
	function ag_avocat_opt( $key, $default = '' ) {
		return get_theme_mod( $key, $default );
	}
}

/**
 * Lit le titre + l'intro d'une section directement depuis la page WP
 * correspondante (Pages > [slug]). Ainsi l'utilisateur edite UNIQUEMENT
 * la page : titre = H2 de la section, premier paragraphe = lead.
 *
 * @param string $slug          Slug de la page
 * @param string $fallback_h2   Titre de secours si la page n'existe pas
 * @param string $fallback_lead Intro de secours
 * @return array [titre, intro]
 */
if ( ! function_exists( 'ag_avocat_page_section_text' ) ) {
	function ag_avocat_page_section_text( $slug, $fallback_h2, $fallback_lead = '' ) {
		$page  = get_page_by_path( $slug );
		$title = $fallback_h2;
		$lead  = $fallback_lead;
		if ( $page ) {
			$title = get_the_title( $page->ID ) ?: $fallback_h2;
			if ( $page->post_excerpt ) {
				$lead = $page->post_excerpt;
			} else {
				$blocks = function_exists( 'parse_blocks' ) ? parse_blocks( $page->post_content ) : array();
				foreach ( $blocks as $block ) {
					if ( ! empty( $block['blockName'] ) && $block['blockName'] === 'core/paragraph' ) {
						$txt = trim( wp_strip_all_tags( $block['innerHTML'] ) );
						if ( $txt ) {
							$lead = wp_trim_words( $txt, 30, '...' );
							break;
						}
					}
				}
			}
		}
		return array( $title, $lead );
	}
}

/**
 * Rend un titre H2 avec auto-italique du dernier mot — preserve le design
 * d'origine (mot final en couleur accent via .ag-section-title em / span).
 */
if ( ! function_exists( 'ag_avocat_render_split_title' ) ) {
	function ag_avocat_render_split_title( $title ) {
		$words = preg_split( '/\s+/', trim( $title ) );
		if ( count( $words ) < 2 ) {
			return esc_html( $title );
		}
		$last  = array_pop( $words );
		$first = implode( ' ', $words );
		return esc_html( $first ) . ' <em>' . esc_html( $last ) . '</em>';
	}
}

/**
 * Get permalink for a page by slug — works with any permalink structure.
 *
 * In Free tier: pages dediees (rendez-vous, expertise, cabinet, honoraires)
 * n'existent pas conceptuellement. On force l'ancre vers la home, meme si
 * une page WP avec ce slug a ete creee par erreur. En Premium+, on utilise
 * la page WP si elle existe, sinon fallback ancre.
 */
function ag_page_url( $slug ) {
	$anchors = array(
		'rendez-vous' => '#ag-rdv',
		'expertise'   => '#ag-domaines',
		'cabinet'     => '#ag-cabinet',
		'honoraires'  => '#ag-honoraires',
	);

	$tier = class_exists( 'AG_Licence_Client' ) ? AG_Licence_Client::get_tier() : 'free';

	if ( 'free' !== $tier ) {
		$page = get_page_by_path( $slug );
		if ( $page ) {
			return get_permalink( $page );
		}
	}

	if ( isset( $anchors[ $slug ] ) ) {
		return home_url( '/' . $anchors[ $slug ] );
	}

	return home_url( '/' . $slug . '/' );
}

/**
 * Enqueue scripts and styles.
 */
function ag_starter_avocat_scripts() {
	wp_enqueue_style(
		'ag-starter-avocat-style',
		get_stylesheet_uri(),
		array(),
		wp_get_theme()->get( 'Version' )
	);
	// Script de réponse imbriquée aux commentaires.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	// Petit script (corrige la classe current-menu-item du menu de secours).
	wp_enqueue_script(
		'ag-starter-avocat-menu',
		get_template_directory_uri() . '/assets/menu-fix.js',
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'ag_starter_avocat_scripts' );

/**
 * Style de bloc + composition (transition vers les thèmes de blocs).
 */
function ag_starter_avocat_block_assets() {
	register_block_style(
		'core/button',
		array(
			'name'  => 'ag-gold',
			'label' => esc_html__( 'Alliance Gold', 'ag-starter-avocat' ),
		)
	);
	if ( function_exists( 'register_block_pattern' ) ) {
		register_block_pattern(
			'ag-starter-avocat/cta-cabinet',
			array(
				'title'   => esc_html__( 'Call to action — Firm', 'ag-starter-avocat' ),
				'content' => '<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center">' . esc_html__( 'Need advice? Book an appointment with the firm.', 'ag-starter-avocat' ) . '</p><!-- /wp:paragraph -->',
			)
		);
	}
}
add_action( 'init', 'ag_starter_avocat_block_assets' );

/**
 * Zone de widgets (pied de page).
 */
function ag_starter_avocat_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer', 'ag-starter-avocat' ),
			'id'            => 'footer-1',
			'description'   => esc_html__( 'Widgets shown in the footer.', 'ag-starter-avocat' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'ag_starter_avocat_widgets_init' );

/**
 * (Build WordPress.org) : on NE désactive PAS les commentaires ni les widgets,
 * et on ne retire aucun menu admin core — interdit par les règles du répertoire.
 * Ces réglages « admin épuré » restent dans la version Premium hors .org.
 */


/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function ag_starter_avocat_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">' . "\n", esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'ag_starter_avocat_pingback_header' );

/**
 * Load the customizer (panels, sections, settings) and its dynamic CSS output.
 */
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/pro-features.php';

add_action( 'after_setup_theme', function () {
    $GLOBALS['ag_pro'] = new AG_Pro_Features( 'ag-starter-avocat' );
}, 20 );

/**
 * Load the Domaine d'expertise CPT and the front-end form handler.
 */
require get_template_directory() . '/inc/cpt-domaine.php';
require get_template_directory() . '/inc/forms.php';

/**
 * Show an admin notice inviting the user to install the companion plugin
 * which provides the one-click demo importer.
 */
function ag_starter_avocat_companion_notice() {
	if ( ! current_user_can( 'install_plugins' ) ) {
		return;
	}
	if ( class_exists( 'AG_Starter_Companion' ) ) {
		return;
	}
	$search_url = admin_url( 'plugin-install.php?s=AG+Starter+Companion&tab=search&type=term' );
	?>
	<div class="ag-welcome-banner" style="background:linear-gradient(135deg,#1a1a2e 0%,#0a0a0f 100%);border:1px solid rgba(212,180,92,.3);border-left:4px solid #D4B45C;border-radius:8px;padding:40px 36px;margin:20px 20px 20px 0;display:flex;align-items:center;gap:32px;flex-wrap:wrap;">
		<div style="flex:1;min-width:280px;">
			<h2 style="color:#fff;font-size:1.6rem;margin:0 0 12px;">🎉 <?php esc_html_e( 'Welcome to AG Starter Avocat!', 'ag-starter-avocat' ); ?></h2>
			<p style="color:rgba(255,255,255,.7);font-size:1.05rem;line-height:1.6;margin:0 0 8px;"><?php esc_html_e( 'Your theme is installed. For a ready-to-use site in one click (pages, menu, settings), install the free AG Starter Companion plugin.', 'ag-starter-avocat' ); ?></p>
			<ul style="color:rgba(255,255,255,.6);font-size:.92rem;margin:12px 0 0;padding-left:18px;">
				<li><?php esc_html_e( 'Pages created automatically (Home, Expertise, Fees, Firm, Appointment)', 'ag-starter-avocat' ); ?></li>
				<li><?php esc_html_e( 'Main menu configured and assigned', 'ag-starter-avocat' ); ?></li>
				<li><?php esc_html_e( 'Home page and permalinks enabled', 'ag-starter-avocat' ); ?></li>
				<li><?php esc_html_e( '100% free, no internet connection required', 'ag-starter-avocat' ); ?></li>
			</ul>
		</div>
		<div style="text-align:center;">
			<a href="<?php echo esc_url( $search_url ); ?>" style="display:inline-block;background:#D4B45C;color:#0a0a0f;font-size:1.05rem;font-weight:700;padding:16px 32px;border-radius:8px;text-decoration:none;box-shadow:0 4px 16px rgba(212,180,92,.3);"><?php esc_html_e( 'Download AG Starter Companion', 'ag-starter-avocat' ); ?></a>
			<p style="color:rgba(255,255,255,.4);font-size:.8rem;margin-top:10px;"><?php esc_html_e( 'Download the ZIP, then Plugins → Add New → Upload', 'ag-starter-avocat' ); ?></p>
			<p style="margin-top:14px;"><a href="https://alliancegroupe-inc.com/guide-avocat?utm_source=wp-admin&amp;utm_medium=ag-starter-avocat&amp;utm_campaign=guide" target="_blank" rel="nofollow noopener" style="color:#D4B45C;font-size:.92rem;text-decoration:underline;">🎁 <?php esc_html_e( 'Get the free guide: 7 pages that attract clients', 'ag-starter-avocat' ); ?></a></p>
		</div>
	</div>
	<?php
}
add_action( 'admin_notices', 'ag_starter_avocat_companion_notice' );

function ag_starter_avocat_dashboard_widget() {
	if ( class_exists( 'AG_Starter_Companion' ) ) return;
	wp_add_dashboard_widget( 'ag_starter_welcome', esc_html__( '🚀 AG Starter Avocat — Setup', 'ag-starter-avocat' ), 'ag_starter_avocat_dashboard_widget_render' );
	global $wp_meta_boxes;
	$widget = $wp_meta_boxes['dashboard']['normal']['core']['ag_starter_welcome'];
	unset( $wp_meta_boxes['dashboard']['normal']['core']['ag_starter_welcome'] );
	$wp_meta_boxes['dashboard']['normal']['high']['ag_starter_welcome'] = $widget;
}
function ag_starter_avocat_dashboard_widget_render() {
	$search_url = admin_url( 'plugin-install.php?s=AG+Starter+Companion&tab=search&type=term' );
	?>
	<div style="text-align:center;padding:20px 0;">
		<p style="font-size:1.15rem;margin:0 0 16px;"><strong><?php esc_html_e( 'Your theme is ready!', 'ag-starter-avocat' ); ?></strong></p>
		<p style="color:#666;margin:0 0 20px;"><?php esc_html_e( 'Install the free AG Starter Companion plugin to automatically create your pages and menu and set up your site in one click.', 'ag-starter-avocat' ); ?></p>
		<a href="<?php echo esc_url( $search_url ); ?>" class="button button-primary button-hero"><?php esc_html_e( 'Download AG Starter Companion', 'ag-starter-avocat' ); ?></a>
		<p style="color:#999;font-size:.85rem;margin-top:12px;"><?php esc_html_e( 'Free — 10 seconds — no sign-up', 'ag-starter-avocat' ); ?></p>
		<p style="margin-top:14px;"><a href="https://alliancegroupe-inc.com/guide-avocat?utm_source=wp-admin&amp;utm_medium=ag-starter-avocat&amp;utm_campaign=guide" target="_blank" rel="nofollow noopener"><?php esc_html_e( '🎁 Get the free guide: 7 pages that attract clients', 'ag-starter-avocat' ); ?></a></p>
	</div>
	<?php
}
add_action( 'wp_dashboard_setup', 'ag_starter_avocat_dashboard_widget' );

/**
 * Invitation discrète à laisser un avis, 7 jours après activation du thème.
 * Dismissible et non bloquante (conforme WordPress.org : aucune fonctionnalité
 * n'est conditionnée à un avis).
 */
function ag_starter_avocat_record_activation() {
	if ( ! get_option( 'ag_starter_avocat_activated_at' ) ) {
		update_option( 'ag_starter_avocat_activated_at', time() );
	}
}
add_action( 'after_switch_theme', 'ag_starter_avocat_record_activation' );

function ag_starter_avocat_review_dismiss() {
	if ( isset( $_GET['ag_avocat_review_off'] ) && check_admin_referer( 'ag_avocat_review_off' ) ) {
		update_user_meta( get_current_user_id(), 'ag_starter_avocat_review_off', 1 );
		wp_safe_redirect( remove_query_arg( array( 'ag_avocat_review_off', '_wpnonce' ) ) );
		exit;
	}
}
add_action( 'admin_init', 'ag_starter_avocat_review_dismiss' );

function ag_starter_avocat_review_notice() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'themes' ), true ) ) {
		return;
	}
	if ( get_user_meta( get_current_user_id(), 'ag_starter_avocat_review_off', true ) ) {
		return;
	}
	$since = (int) get_option( 'ag_starter_avocat_activated_at', 0 );
	if ( ! $since ) {
		update_option( 'ag_starter_avocat_activated_at', time() );
		return;
	}
	if ( ( time() - $since ) < 7 * DAY_IN_SECONDS ) {
		return;
	}
	$dismiss = wp_nonce_url( add_query_arg( 'ag_avocat_review_off', '1' ), 'ag_avocat_review_off' );
	echo '<div class="notice notice-info is-dismissible"><p>';
	printf(
		wp_kses(
			/* translators: 1: review link, 2: dismiss link */
			__( 'Is the <strong>AG Starter Avocat</strong> theme useful to you? An honest review (30 seconds) helps other law firms discover it. <a href="%1$s" target="_blank" rel="noopener">Leave a review</a> &middot; <a href="%2$s">Dismiss</a>', 'ag-starter-avocat' ),
			array( 'strong' => array(), 'a' => array( 'href' => array(), 'target' => array(), 'rel' => array() ) )
		),
		'https://wordpress.org/support/theme/ag-starter-avocat/reviews/#new-post',
		esc_url( $dismiss )
	);
	echo '</p></div>';
}
add_action( 'admin_notices', 'ag_starter_avocat_review_notice' );

// Guide d'utilisation (admin)
require_once get_template_directory() . '/inc/guide.php';

// Pré-remplissage auto depuis ag-prefill.json (sites generes par le Createur AG)
require_once get_template_directory() . '/inc/ag-prefill.php';

/**
 * Credit footer — attribution Alliance Groupe (lien VISIBLE, conforme Google).
 * Retirable uniquement via le code (pas d'option admin), comme Astra/OceanWP.
 */
if ( ! function_exists( 'ag_avocat_credit' ) ) :
	function ag_avocat_credit() {
		echo '<p class="ag-credit"><small>';
		printf(
			wp_kses( __( 'Theme: %s', 'ag-starter-avocat' ), array( 'a' => array( 'href' => array(), 'title' => array(), 'rel' => array() ) ) ),
			'<a href="https://alliancegroupe-inc.com/wordpress-avocat" rel="nofollow" title="AG Starter Avocat">AG Starter Avocat</a>'
		);
		echo '</small></p>';
	}
endif;
